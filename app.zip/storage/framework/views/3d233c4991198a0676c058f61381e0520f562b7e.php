<?php $__env->startSection('header'); ?>
<?php $__env->startSection('title'); ?>Editor de Cursos - Panel de Control <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<!-- A D M I N I S T R A T E   C O U R S E S -->

<div class="container-fluid controlPanel">
    <div class="row h-100">
        <div class="col-12 overflow-auto">
            <div id="courseFilter" class="row bg-grey p-2 pb-4">
                <div class="col-lg-2 col-md-4 col-sm-6 col-12">
                    <label for="courseFilterTitle" class="color-deep-blue"><strong>Título</strong></label>
                    <input class="form-control" type="text" id="courseFilterTitle">
                </div>
                <div class="col-lg-2 col-md-4 col-sm-6 col-12">
                    <label for="courseFilterLocation" class="color-deep-blue"><strong>Localización</strong></label>
                    <select id="courseFilterLocation" class="form-control">
                        <option value="Todos" selected>Todos</option>
                        <option value="Fuerteventura">Fuerteventura</option>
                        <option value="Gran Canaria">Gran Canaria</option>
                        <option value="Tenerife">Tenerife</option>
                    </select>
                </div>
                <div class="col-lg-2 col-md-4 col-sm-6 col-12">
                    <label for="courseFilterSector" class="color-deep-blue"><strong>Sector</strong></label>
                    <input class="form-control" type="text" id="courseFilterSector">
                </div>
                <div class="col-lg-2 col-md-4 col-sm-6 col-12">
                    <label for="courseFilterLevel" class="color-deep-blue"><strong>Nivel</strong></label>
                    <input class="form-control" type="number" id="courseFilterLevel">
                </div>
                <div class="col-lg-2 col-md-4 col-sm-6 col-12">
                    <label for="courseFilterType" class="color-deep-blue"><strong>Tipo</strong></label>
                    <select id="courseFilterType" class="form-control">
                        <option value="Todos" selected>Todos</option>
                        <option value="Gratuito">Gratuito</option>
                        <option value="Privado">Privado</option>
                    </select>
                </div>
                <div class="col-lg-2 col-md-4 col-sm-6 col-12">
                    <label for="courseFilterOnSite" class="color-deep-blue"><strong>Presencial</strong></label>
                    <select id="courseFilterOnSite" class="form-control">
                        <option value="Todos" selected>Todos</option>
                        <option value="Presencial">Presencial</option>
                        <option value="Semipresencial">Semipresencial</option>
                        <option value="Teleformación">Teleformación</option>
                    </select>
                </div>
            </div>
            <div class="container-fluid courses mt-5">
                <div>
                    <i title="Añadir curso" data-toggle="modal" data-target="#addCourse" class="glyphicon glyphicon-plus bg-deep-blue text-white rounded-circle centerHorizontal iconBig interactive mb-5 p-3"></i>
                    <div class="row mb-4">
                        <div class="col-lg-8 offset-lg-2 col-12 offset-0">
                            <a class="float-right color-deep-blue" href="<?php echo e(url('controlPanel/courses')); ?>"><strong>Editar Página</strong></a>
                        </div>
                    </div>
                </div>

                <!-- Add Modal -->
                <div class="modal fade addCourse" id="addCourse" tabindex="-1" role="dialog" aria-labelledby="Herramienta para añadir cursos" aria-hidden="true">
                    <form class="form-group addCourseForm mb-0" data-nm="<?php echo e($nextModule); ?>" data-nu="<?php echo e($nextUnit); ?>" action="<?php echo e(url("addCourse")); ?>" method="post">
                     <?php echo e(csrf_field()); ?>

                        <div class="modal-dialog modal-lg" role="document">
                            <div class="modal-content">
                                <div class="modal-header border-0">
                                    <h5 class="modal-title w-100 text-center text-overflow-ellipsis">Añadir Curso <strong></strong></h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body px-md-5 px-2">
                                    <ul class="nav nav-pills d-sm-flex d-block mb-3" id="pills-tab" role="tablist">
                                        <li class="nav-item">
                                            <a class="nav-link text-center active" id="pills-generic-tab-add" data-toggle="pill" href="#pills-generic-add" role="tab" aria-controls="pills-generic" aria-selected="true"><strong>General</strong></a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link text-center" id="pills-specific-tab-add" data-toggle="pill" href="#pills-specific-add" role="tab" aria-controls="pills-specific" aria-selected="false"><strong>Específico</strong></a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link text-center" id="pills-content-tab-add" data-toggle="pill" href="#pills-content-add" role="tab" aria-controls="pills-content" aria-selected="false"><strong>Contenidos</strong></a>
                                        </li>
                                    </ul>
                                    <div class="tab-content" id="pills-tabContent">
                                        <div class="tab-pane fade show active" id="pills-generic-add" role="tabpanel" aria-labelledby="pills-generic-tab">
                                            <div class="container-fluid">
                                                <div class="row">
                                                    <div class="col-md-6 col-12">
                                                        <label for="courseAddTitle" class="color-deep-blue"><h6 title="Este campo es obligatorio">Título<span class="text-danger">*</span></h6></label>
                                                        <input id="courseAddTitle" class="form-control mb-2" type="text" name="title" required>
                                                        <label for="courseAddSector" class="color-deep-blue"><h6 title="Este campo es obligatorio">Sector<span class="text-danger">*</span></h6></label>
                                                        <input id="courseAddSector" class="form-control mb-2" type="text" name="sector" required>
                                                        <label for="courseAddLocation" class="color-deep-blue"><h6 title="Este campo es obligatorio">Localización<span class="text-danger">*</span></h6></label>
                                                        <select id="courseAddLocation" class="form-control mb-2" name="location" required>
                                                            <option value="Fuerteventura" selected>Fuerteventura</option>
                                                            <option value="Gran Canaria">Gran Canaria</option>
                                                            <option value="Tenerife">Tenerife</option>
                                                        </select>
                                                        <label for="courseAddType" class="color-deep-blue"><h6 title="Este campo es obligatorio">Tipo<span class="text-danger">*</span></h6></label>
                                                        <select id="courseAddType" class="form-control mb-2" name="type" required>
                                                            <option value="Gratuito" selected>Gratuito</option>
                                                            <option value="Privado">Privado</option>
                                                        </select>
                                                        <div id="courseReceiverBlock">
                                                        <label for="courseAddReceiver" class="color-deep-blue"><h6 title="Este campo es obligatorio">Destinatario<span class="text-danger">*</span></h6></label>
                                                        <select id="courseAddReceiver" class="form-control mb-2" name="receiver" required>
                                                            <option value="Desempleados/as" selected>Desempleados/as</option>
                                                            <option value="Trabajadores/as">Trabajadores/as</option>
                                                            <option value="Desempleados/as y Trabajadores/as">Desempleados/as y Trabajadores/as</option>
                                                        </select>
                                                    </div>
                                                    <div id="coursePriceBlock" class="d-none">
                                                    <label for="courseAddPrice" class="color-deep-blue"><h6 title="Este campo es opcional">Precio</h6></label>
                                                    <input id="courseEditPrice" type="number" step="0.01" class="form-control mb-2" name="price">
                                                </div>
                                                <label for="courseAddOnSite" class="color-deep-blue"><h6 title="Este campo es obligatorio">Asistencia<span class="text-danger">*</span></h6></label>
                                                <select id="courseAddOnSite" class="form-control mb-2" name="onSite" required>
                                                    <option value="Presencial" selected>Presencial</option>
                                                    <option value="Semipresencial">Semipresencial</option>
                                                    <option value="Teleformación">Teleformación</option>
                                                </select>
                                            </div>
                                            <div class="col-md-6 col-12">
                                                <label for="courseAddImage" class="color-deep-blue"><h6 title="Este campo es obligatorio">Imagen<span class="text-danger">*</span></h6></label>
                                                <div class="file-loading">
                                                    <input id="courseAddImage" name="image" type="file" accept="image">
                                                </div>
                                                <div class="form-check mt-4">
                                                    <input class="form-check-input" type="checkbox" name="promote" id="promoteAddCourse">
                                                    <label class="form-check-label" for="promoteAddCourse"><h6 title="Este campo es opcional" class="color-deep-blue ml-1">Promocionar<small class="text-danger"> (Al marcar esta opción, se dará preferencia al curso en el banner y se mostrará como inicio inmediato en caso de no especificar una fecha de inicio)</small></h6></label>
                                                </div>
                                                <div class="form-check mt-3">
                                                    <input class="form-check-input" type="checkbox" name="hidden" id="hiddenAddCourse">
                                                    <label class="form-check-label" for="hiddenAddCourse"><h6 title="Este campo es opcional" class="color-deep-blue ml-1">Ocultar<small class="text-danger"> (Al marcar esta opción, el curso no será visible para los usuarios)</small></h6></label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="container-fluid mt-4 mb-2">
                                        <div class="float-right mb-2">
                                            <button type="button" class="btn cpBtn bg-deep-blue text-white border-deep-blue px-4 toggleSpecific"><strong>Siguiente</strong></button>
                                        </div>
                                    </div>
                                </div>
                                <div class="tab-pane fade" id="pills-specific-add" role="tabpanel" aria-labelledby="pills-specific-tab">
                                    <label for="courseAddDescription" class="color-deep-blue"><h6 title="Este campo es opcional">Descripción</h6></label>
                                    <div id="courseAddDescription" class="mb-2 courseAddDescription"></div>
                                    <input type="hidden" name="description">
                                    <div class="row mb-2">
                                        <div class="col-md-6 col-12">
                                            <label for="courseAddLevel" class="color-deep-blue"><h6 title="Este campo es opcional">Nivel</h6></label>
                                            <input id="courseAddLevel" class="form-control" type="number" name="level">
                                        </div>
                                        <div class="col-md-6 col-12">
                                            <label for="courseAddHours" class="color-deep-blue"><h6 title="Este campo es opcional">Horas</h6></label>
                                            <input id="courseAddHours" class="form-control" type="number" name="hours">
                                        </div>
                                    </div>
                                    <div class="row mb-2">
                                        <div class="col-md-6 col-12">
                                            <label for="courseAddInitDate" class="color-deep-blue"><h6 title="Este campo es opcional">Fecha de Inicio <small class="text-danger">(Dejar vacío para marcar el curso como Próximamente)</small></h6></label>
                                            <input id="courseAddInitDate" class="form-control" type="text" name="initDate" autocomplete="off">
                                        </div>
                                        <div class="col-md-6 col-12">
                                            <label for="courseAddEndDate" class="color-deep-blue"><h6 title="Este campo es opcional">Fecha de Fin</h6></label>
                                            <input id="courseAddEndDate" class="form-control" type="text" name="endDate" autocomplete="off">
                                        </div>
                                    </div>
                                    <div class="row mb-2">
                                        <div class="col-md-6 col-12">
                                            <label for="courseAddSchedule" class="color-deep-blue"><h6 title="Este campo es opcional">Horario</h6></label>
                                            <input id="courseAddSchedule" class="form-control" type="text" name="schedule" placeholder="Ejemplo: De 8:00h a 16:00h">
                                        </div>
                                        <div class="col-md-6 col-12">
                                            <label for="courseAddTeacher" class="color-deep-blue"><h6 title="Este campo es opcional">Docente</h6></label>
                                            <input id="courseAddTeacher" class="form-control" type="text" name="teacher">
                                        </div>
                                    </div>
                                    <div id="courseTeacherDescriptionBlock" class="mb-2 d-none">
                                        <label for="courseAddTeacherDescription" class="color-deep-blue"><h6 title="Este campo es opcional">Información adicional sobre el docente</h6></label>
                                        <div id="courseAddTeacherDescription" class="courseAddTeacherDescription"></div>
                                        <input type="hidden" name="teacherDescription">
                                    </div>
                                    <div>
                                        <label for="courseAddRequirements" class="color-deep-blue"><h6 title="Este campo es opcional">Requisitos</h6></label>
                                        <div id="courseAddRequirements" class="mb-2 courseAddRequirements"></div>
                                        <input type="hidden" name="requirements">
                                        <p class="text-right"><small class="text-danger mb-2">(Los cursos se ocultan pasados 5 días de la fecha de inicio)</small></p>
                                    </div>
                                    <div class="container-fluid mt-4">
                                        <div class="float-right mb-2">
                                            <button type="button" class="btn cpBtn color-deep-blue border-deep-blue px-4 toggleGeneric"><strong>Anterior</strong></button>
                                            <button type="button" class="btn cpBtn bg-deep-blue text-white border-deep-blue px-4 toggleContent" ><strong>Siguiente</strong></button>
                                        </div>
                                    </div>
                                </div>
                                <div class="tab-pane fade" id="pills-content-add" role="tabpanel" aria-labelledby="pills-content-tab">
                                    <h6 class="color-deep-blue mb-3" title="Este campo es opcional">Módulos y unidades formativas</h6>
                                    <div id="addModules" class="modules"></div>
                                    <div class="container-fluid p-0 mt-4 mb-2">
                                        <div class="mb-4"><i class="centerHorizontal bg-deep-blue text-white rounded-circle p-3 glyphicon glyphicon-plus interactive addModule" title="Añadir módulo"></i></div>
                                        <div id="addProfessionalDepartures">
                                            <h6 class="color-deep-blue mb-3" title="Este campo es opcional">Salidas profesionales</h6>
                                            <div class="my-4">
                                                <i class="centerHorizontal bg-deep-blue text-white rounded-circle p-3 glyphicon glyphicon-plus interactive addProfessionalDeparture" title="Añadir salida profesional"></i>
                                            </div>
                                        </div>
                                        <div class="float-right mb-2">
                                            <button type="button" class="btn cpBtn color-deep-blue border-deep-blue px-4 toggleSpecific"><strong>Anterior</strong></button>
                                            <button id="addCourseSubmit" type="submit" class="btn cpBtn bg-deep-blue text-white border-deep-blue px-4"><strong>Guardar</strong></button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>

        <script type="text/javascript" id="courseAddScript">
            $(window).on("load", function(){
                let uploaded = false;

                $("#courseAddImage").fileinput({
                    theme: "explorer",
                    uploadUrl: "<?php echo e(url('uploadImage/'.$nextCourse.'/course')); ?>",
                    allowedFileExtensions: ["jpg", "jpeg", "png", "gif"],
                    maxFileCount: 1,
                    maxFileSize: 10000,
                    showAjaxErrorDetails: false
                }).on('fileuploaded', function () {
                    uploaded = true;
                });

                $('.addCourseForm').on('submit', function () {
                   if(!uploaded){
                       alert('Debe subir una foto antes de publicar el curso.');
                       return false;
                   }
                });

                $('#addCourseSubmit').on('click', function (e) {
                    let requiredFields = $('.addCourseForm').find('[required]');

                    requiredFields.each(function (index, value) {
                       if($(value).val().length < 1) {
                           e.preventDefault();

                           $('[href="#'+$(value).closest('.tab-pane').attr('id')+'"]').trigger('click');

                           setTimeout(function () {
                               $(value).focus();
                           }, 200);
                           return false;
                       }
                    });
                });

                textEditorFromReference("#courseAddDescription");
                textEditorFromReference("#courseAddTeacherDescription");
                textEditorFromReference("#courseAddRequirements");
                $("#courseAddInitDate").datepicker();
                $("#courseAddEndDate").datepicker();
                $("#addModules").accordion({
                    header: ".module",
                    active: 3,
                    collapsible: true,
                    heightStyle: "content",
                });
                $("#courseAddScript").remove();
            });
        </script>

                <?php

                    if(isset($courses)){
                        foreach ($courses as $course){
                            echo '<div class="row mb-4 course" data-title="'.$course['title'].'" data-level="'.$course['level'].'" data-sector="'.$course['sector'].'" data-location="'.$course['location'].'" data-type="'.$course['type'].'" data-onSite="'.$course['onSite'].'">
                                <div class="col-xl-8 offset-xl-2 col-lg-10 offset-lg-1 col-12 offset-0">
                                <div class="container-fluid bg-grey rounded shadow p-4';
                            if(!$course['display'] || ($course['init_date'] && strtotime('+5 days', strtotime(DateTime::createFromFormat('d/m/Y', $course['init_date'])->format('Y-m-d'))) < strtotime(date('Y-m-d')))) echo ' hidden';
                            echo'"><div class="row">
                                <div class="col-md-3 col-sm-5 offset-sm-0 col-12">
                                <img class="w-100 fixedHeightImg p-2 rounded" alt="Imagen de portada del curso '.$course['title'].'" src="'.asset('images/uploads/'.$course['image']).'">
                                </div>
                                <div class="col-md-5 col-sm-7 col-12">
                                <h4 class="color-deep-blue clamp pb-1"><strong>'.$course['title'].'</strong></h4><div>';
                                if($course['level'] && strlen($course['level']) > 0) echo '<h5 class="color-deep-blue d-lg-inline-block d-none pr-3">Nivel '.$course['level'].'</h5>';
                                echo'<h5 class="color-deep-blue d-lg-inline-block d-none pr-3">'.$course['location'].'</h5>
                                <h5 class="color-deep-blue d-lg-inline-block d-none pr-3">'.$course['type'].'</h5>
                                <h5 class="color-deep-blue d-lg-inline-block d-none pr-3">'.$course['onSite'].'</h5>
                                <h5 class="color-deep-blue d-lg-inline-block d-none pr-3">'.$course['sector'].'</h5>
                                </div>
                                </div>
                                <div class="col-md-4 col-12 p-0 d-flex justify-content-center align-items-center">
                                <div class="container-fluid">
                                <div class="row">
                                <div class="col-6">
                                <button class="btn cpBtn color-deep-blue border-deep-blue px-4 float-right" data-toggle="modal" data-target="#deleteCourseModal-'.$course['id'].'"><strong>Borrar</strong></button>
                                </div>
                                <div class="col-6">
                                <button class="btn cpBtn bg-deep-blue color-grey border-deep-blue px-4" data-toggle="modal" data-target="#editCourseModal-'.$course['id'].'"><strong>Editar</strong></button>
                                </div>
                                </div>
                                </div>
                                </div>
                                </div>
                                </div>
                                </div>
                                </div>
                                <!-- Edit Modal -->
                                <div class="modal fade editCourse" id="editCourseModal-'.$course['id'].'" tabindex="-1" role="dialog" aria-labelledby="Editor del curso '.$course['title'].'" aria-hidden="true">
                                <form id="editCourseForm'.$course['id'].'" class="form-group editCourseForm mb-0" data-id="'.$course['id'].'" data-nm="'.$nextModule.'" data-nu="'.$nextUnit.'" action="'.url("editCourse").'" method="post">';
                                echo csrf_field();
                                echo'<input type="hidden" name="course" value="'.$course["id"].'">
                                <div class="modal-dialog modal-lg" role="document">
                                <div class="modal-content">
                                <div class="modal-header border-0">
                                <h5 class="modal-title w-100 text-center text-overflow-ellipsis">Editar <strong>'.$course['title'].'</strong></h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                                </button>
                                </div>
                                <div class="modal-body px-md-5 px-2">
                                <ul class="nav nav-pills d-md-flex d-block mb-3" id="pills-tab" role="tablist">
                                <li class="nav-item">
                                <a class="nav-link text-center active" id="pills-generic-tab'.$course['id'].'" data-toggle="pill" href="#pills-generic'.$course['id'].'" role="tab" aria-controls="pills-generic" aria-selected="true"><strong>General</strong></a>
                                </li>
                                <li class="nav-item">
                                <a class="nav-link text-center" id="pills-specific-tab'.$course['id'].'" data-toggle="pill" href="#pills-specific'.$course['id'].'" role="tab" aria-controls="pills-specific" aria-selected="false"><strong>Específico</strong></a>
                                </li>
                                <li class="nav-item">
                                <a class="nav-link text-center" id="pills-content-tab'.$course['id'].'" data-toggle="pill" href="#pills-content'.$course['id'].'" role="tab" aria-controls="pills-content" aria-selected="false"><strong>Contenidos</strong></a>
                                </li>
                                </ul>
                                <div class="tab-content" id="pills-tabContent">
                                <div class="tab-pane fade show active" id="pills-generic'.$course['id'].'" role="tabpanel" aria-labelledby="pills-generic-tab">
                                <div class="container-fluid">
                                <div class="row">
                                <div class="col-md-6 col-12">
                                <label for="courseEditTitle'.$course['id'].'" class="color-deep-blue"><h6 title="Este campo es obligatorio">Título<span class="text-danger">*</span></h6></label>
                                <input id="courseEditTitle'.$course['id'].'" class="form-control mb-2" type="text" value="'.$course['title'].'" name="title" required>
                                <label for="courseEditSector'.$course['id'].'" class="color-deep-blue"><h6 title="Este campo es obligatorio">Sector<span class="text-danger">*</span></h6></label>
                                <input id="courseEditSector'.$course['id'].'" class="form-control mb-2" type="text" value="'.$course['sector'].'" name="sector" required>
                                <label for="courseEditLocation'.$course['id'].'" class="color-deep-blue"><h6 title="Este campo es obligatorio">Localización<span class="text-danger">*</span></h6></label>
                                <select id="courseEditLocation'.$course['id'].'" class="form-control mb-2" name="location" required>
                                <option value="Fuerteventura" '; if($course['location'] == 'Fuerteventura') echo 'selected'; echo'>Fuerteventura</option>
                                <option value="Gran Canaria"'; if($course['location'] == 'Gran Canaria') echo 'selected'; echo'>Gran Canaria</option>
                                <option value="Tenerife"'; if($course['location'] == 'Tenerife') echo 'selected'; echo'>Tenerife</option>
                                </select>
                                <label for="courseEditType'.$course['id'].'" class="color-deep-blue"><h6 title="Este campo es obligatorio">Tipo<span class="text-danger">*</span></h6></label>
                                <select id="courseEditType'.$course['id'].'" class="form-control mb-2" name="type" required>
                                <option value="Gratuito" '; if($course['type'] == 'Gratuito') echo 'selected'; echo'>Gratuito</option>
                                <option value="Privado"'; if($course['type'] == 'Privado') echo 'selected'; echo'>Privado</option>
                                </select>
                                <div id="courseReceiverBlock"';
                                if($course['type'] != "Gratuito") echo 'class="d-none"';
                                echo'>
                                <label for="courseEditReceiver'.$course['id'].'" class="color-deep-blue"><h6 title="Este campo es obligatorio">Destinatario<span class="text-danger">*</span></h6></label>
                                <select id="courseEditReceiver'.$course['id'].'" class="form-control mb-2" name="receiver" required>
                                <option value="Desempleados/as" '; if($course['receiver'] == 'Desempleados/as') echo 'selected'; echo'>Desempleados/as</option>
                                <option value="Trabajadores/as"'; if($course['receiver'] == 'Trabajadores/as') echo 'selected'; echo'>Trabajadores/as</option>
                                <option value="Desempleados/as y Trabajadores/as"'; if($course['receiver'] == 'Desempleados/as y Trabajadores/as') echo 'selected'; echo'>Desempleados/as y Trabajadores/as</option>
                                </select>
                                </div>
                                <div id="coursePriceBlock"';
                                if($course['type'] != "Privado") echo 'class="d-none"';
                                echo'>
                                <label for="courseEditPrice'.$course['id'].'" class="color-deep-blue"><h6 title="Este campo es opcional">Precio</h6></label>
                                <input id="courseEditPrice'.$course['id'].'" type="number" step="0.01" class="form-control mb-2" name="price" value="'.$course['price'].'">
                                </div>
                                <label for="courseEditOnSite'.$course['id'].'" class="color-deep-blue"><h6 title="Este campo es obligatorio">Asistencia<span class="text-danger">*</span></h6></label>
                                <select id="courseEditOnSite'.$course['id'].'" class="form-control mb-2" name="onSite" required>
                                <option value="Presencial" '; if($course['onSite'] == 'Presencial') echo 'selected'; echo'>Presencial</option>
                                <option value="Semipresencial" '; if($course['onSite'] == 'Semipresencial') echo 'selected'; echo'>Semipresencial</option>
                                <option value="Teleformación"'; if($course['onSite'] == 'Teleformación') echo 'selected'; echo'>Teleformación</option>
                                </select>
                                </div>
                                <div class="col-md-6 col-12">
                                <label for="courseEditImage'.$course['id'].'" class="color-deep-blue"><h6 title="Este campo es obligatorio">Imagen<span class="text-danger">*</span></h6></label>
                                <div class="file-loading">
                                <input id="courseEditImage'.$course['id'].'" name="image" type="file" accept="image">
                                </div>
                                <div class="form-check mt-4">
                                <input class="form-check-input" type="checkbox" name="promote" id="promoteCourse'.$course['id'].'" ';
                                if($course['promote'] > 0) echo 'checked="true"';
                                echo'>
                                <label class="form-check-label" for="promoteCourse'.$course['id'].'"><h6 title="Este campo es opcional" class="color-deep-blue ml-1">Promocionar<small class="text-danger"> (Al marcar esta opción, se dará preferencia al curso en el banner y se mostrará como inicio inmediato en caso de no especificar una fecha de inicio)</small></h6></label>
                                </div>
                                <div class="form-check mt-3">
                                <input class="form-check-input" type="checkbox" name="hidden" id="hiddenCourse'.$course['id'].'" ';
                                if($course['display'] < 1) echo 'checked="true"';
                                echo'>
                                <label class="form-check-label" for="hiddenCourse'.$course['id'].'"><h6 title="Este campo es opcional" class="color-deep-blue ml-1">Ocultar<small class="text-danger"> (Al marcar esta opción, el curso no será visible para los usuarios)</small></h6></label>
                                </div>
                                </div>
                                </div>
                                </div>
                                <div class="container-fluid mt-4 mb-2">
                                <div class="float-right mb-2">
                                <button type="button" class="btn cpBtn bg-deep-blue text-white border-deep-blue px-4 toggleSpecific" data-target="'.$course['id'].'"><strong>Siguiente</strong></button>
                                </div>
                                </div>
                                </div>
                                <div class="tab-pane fade" id="pills-specific'.$course['id'].'" role="tabpanel" aria-labelledby="pills-specific-tab">
                                <label for="courseEditDescription'.$course['id'].'" class="color-deep-blue"><h6 title="Este campo es opcional">Descripción</h6></label>
                                <div id="courseEditDescription'.$course['id'].'" class="mb-2 courseEditDescription">'.$course['description'].'</div>
                                <input type="hidden" name="description" value=\''.$course['description'].'\'">
                                <div class="row mb-2">
                                <div class="col-md-6 col-12">
                                <label for="courseEditLevel'.$course['id'].'" class="color-deep-blue"><h6 title="Este campo es opcional">Nivel</h6></label>
                                <input id="courseEditLevel'.$course['id'].'" class="form-control" type="number" name="level" value="'.$course['level'].'">
                                </div>
                                <div class="col-md-6 col-12">
                                <label for="courseEditHours'.$course['id'].'" class="color-deep-blue"><h6 title="Este campo es opcional">Horas</h6></label>
                                <input id="courseEditHours'.$course['id'].'" class="form-control" type="number" name="hours" value="'.$course['hours'].'">
                                </div>
                                </div>
                                <div class="row mb-2">
                                <div class="col-md-6 col-12">
                                <label for="courseEditInitDate'.$course['id'].'" class="color-deep-blue"><h6 title="Este campo es opcional">Fecha de Inicio <small class="text-danger">(Dejar vacío para marcar el curso como Próximamente)</small></h6></label>
                                <input id="courseEditInitDate'.$course['id'].'" class="form-control" type="text" name="initDate" value="'.$course['init_date'].'" autocomplete="off">
                                </div>
                                <div class="col-md-6 col-12">
                                <label for="courseEditEndDate'.$course['id'].'" class="color-deep-blue"><h6 title="Este campo es opcional">Fecha de Fin</h6></label>
                                <input id="courseEditEndDate'.$course['id'].'" class="form-control" type="text" name="endDate" value="'.$course['end_date'].'" autocomplete="off">
                                </div>
                                </div>
                                <div class="row mb-2">
                                <div class="col-md-6 col-12">
                                <label for="courseEditSchedule'.$course['id'].'" class="color-deep-blue"><h6 title="Este campo es opcional">Horario</h6></label>
                                <input id="courseEditSchedule'.$course['id'].'" class="form-control" type="text" name="schedule" value="'.$course['schedule'].'" placeholder="Ejemplo: De 8:00h a 16:00h">
                                </div>
                                <div class="col-md-6 col-12">
                                <label for="courseEditTeacher'.$course['id'].'" class="color-deep-blue"><h6 title="Este campo es opcional">Docente</h6></label>
                                <input id="courseEditTeacher'.$course['id'].'" class="form-control" type="text" name="teacher" value="'.$course['teacher'].'">
                                </div>
                                </div>
                                <div id="courseTeacherDescriptionBlock" class="mb-2 ';
                                if(strlen($course['teacher']) == 0) echo 'd-none';
                                echo'">
                                <label for="courseEditTeacherDescription'.$course['id'].'" class="color-deep-blue"><h6 title="Este campo es opcional">Información adicional sobre el docente</h6></label>
                                <div id="courseEditTeacherDescription'.$course['id'].'" class="courseEditTeacherDescription">'.$course['teacherDescription'].'</div>
                                <input type="hidden" name="teacherDescription" value=\''.$course['teacherDescription'].'\'">
                                </div>
                                <div>
                                <label for="courseEditRequirements'.$course['id'].'" class="color-deep-blue"><h6 title="Este campo es opcional">Requisitos</h6></label>
                                <div id="courseEditRequirements'.$course['id'].'" class="mb-2 courseEditRequirements">'.$course['requirements'].'</div>
                                <input type="hidden" name="requirements" value=\''.$course['requirements'].'\'">
                                <p class="text-right"><small class="text-danger mb-2">(Los cursos se ocultan pasados 5 días de la fecha de inicio)</small></p>
                                </div>
                                <div class="container-fluid mt-4">
                                <div class="float-right mb-2">
                                <button type="button" class="btn cpBtn color-deep-blue border-deep-blue px-4 toggleGeneric" data-target="'.$course['id'].'"><strong>Anterior</strong></button>
                                <button type="button" class="btn cpBtn bg-deep-blue text-white border-deep-blue px-4 toggleContent" data-target="'.$course['id'].'"><strong>Siguiente</strong></button>
                                </div>
                                </div>
                                </div>
                                <div class="tab-pane fade" id="pills-content'.$course['id'].'" role="tabpanel" aria-labelledby="pills-content-tab">
                                <h6 class="color-deep-blue mb-3" title="Este campo es opcional">Módulos y unidades formativas</h6>
                                <div id="editModules'.$course['id'].'" class="modules">';
                                foreach ($course['modules'] as $module){
                                    echo '<div class="module d-flex align-items-center mb-2">
                                        <div class="d-flex w-100">
                                        <div class="container-fluid">
                                        <div class="row">
                                        <div class="col-md-4 col-12 p-0 pb-1 pr-1">
                                        <p class="color-deep-blue ml-2 mb-2"><strong>Código</strong></p>
                                        <input class="form-control ml-2 accordionInput" name="moduleCode'.$module[0]['id'].'" type="text" placeholder="Código del módulo" value="'.$module[0]['code'].'">
                                        </div>
                                        <div class="col-md-4 col-12 pb-1 px-1">
                                        <p class="color-deep-blue ml-2 mb-2"><strong>Título</strong></p>
                                        <input class="form-control ml-2 accordionInput" name="moduleTitle'.$module[0]['id'].'" type="text"  placeholder="Nombre del módulo" value="'.$module[0]['title'].'" required>
                                        </div>
                                        <div class="col-md-4 col-12 pb-1 pl-1">
                                        <p class="color-deep-blue ml-2 mb-2"><strong>Horas</strong></p>
                                        <input class="form-control ml-2 accordionInput" name="moduleHours'.$module[0]['id'].'" type="number"  placeholder="Total de horas" value="'.$module[0]['hours'].'">
                                        </div>
                                        </div>
                                        </div>
                                        </div>
                                        <div><i title="Borrar módulo" class="glyphicon glyphicon-remove-circle iconBig mx-4 color-deep-blue rounded-circle courseDeleteField interactive"></i></div>
                                        </div><div>';

                                    foreach ($module[1] as $unit)
                                        echo '<div class="d-md-flex d-block align-items-center mb-2 ml-2">
                                            <input class="form-control mb-2" name="unitCode'.$unit['id'].'" type="text" placeholder="Código de la unidad" value="'.$unit['code'].'">
                                            <input class="form-control mb-2 ml-md-2 ml-0" name="unitTitle'.$unit['id'].'" type="text" placeholder="Nombre de la unidad" value="'.$unit['title'].'" required>
                                            <input class="form-control mb-2 ml-md-2 ml-0" name="unitHours'.$unit['id'].'" type="number" placeholder="Total de horas" value="'.$unit['hours'].'">
                                            <div class="pb-md-0 pb-4"><i title="Borrar unidad formativa" class="glyphicon glyphicon-remove-circle iconBig color-deep-blue ml-4 float-md-none float-right rounded-circle interactive courseDeleteField"></i></div>
                                            </div>';

                                    echo '<i class="centerHorizontal bg-deep-blue text-white rounded-circle p-3 glyphicon glyphicon-plus interactive addUnit" title="Añadir unidad formativa"></i></div>';
                                }
                                echo'</div>
                                <div class="container-fluid mt-4 mb-2">
                                <div class="mb-4"><i class="centerHorizontal bg-deep-blue text-white rounded-circle p-3 glyphicon glyphicon-plus interactive addModule" title="Añadir módulo"></i></div>
                                <div id="editProfessionalDepartures">
                                <h6 class="color-deep-blue mb-3" title="Este campo es opcional">Salidas profesionales</h6>';

                                foreach ($course['professionalDepartures'] as $professionalDeparture){
                                    echo '<div class="d-inline-flex w-50 align-items-center pr-4 mb-2">
                                          <input type="text" class="form-control mr-2" name="professionalDepartures[]" value="'.$professionalDeparture['title'].'" placeholder="Salida Profesional">
                                          <i title="Borrar salida profesional" class="glyphicon glyphicon-remove color-deep-blue interactive deleteProfessionalDeparture"></i>
                                          </div>';
                                }

                                echo'<div class="mt-4">
                                <i class="centerHorizontal bg-deep-blue text-white rounded-circle mb-4 p-3 glyphicon glyphicon-plus interactive addProfessionalDeparture" title="Añadir salida profesional"></i>
                                </div>
                                </div>
                                <div class="float-right mb-2">
                                <button type="button" class="btn cpBtn color-deep-blue border-deep-blue px-4 toggleSpecific" data-target="'.$course['id'].'"><strong>Anterior</strong></button>
                                <button id="editCourseSubmit'.$course['id'].'" type="submit" class="btn cpBtn bg-deep-blue text-white border-deep-blue px-4"><strong>Guardar</strong></button>
                                </div>
                                </div>
                                </div>
                                </div>
                                </div>
                                </div>
                                </div>
                                </form>
                                </div>
                                <!-- Delete Modal -->
                                <div class="modal fade" id="deleteCourseModal-'.$course['id'].'" tabindex="-1" role="dialog" aria-labelledby="Confirmación ¿desea borrar el curso '.$course['title'].'?" aria-hidden="true">
                                <form action="'.url("deleteCourse").'" method="post">';
                                echo csrf_field();
                                echo'<input type="hidden" name="course" value="'.$course["id"].'">
                                <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                <div class="modal-header border-0">
                                <h5 class="modal-title w-100 text-center text-overflow-ellipsis">Borrar <strong>'.$course['title'].'</strong></h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                                </button>
                                </div>
                                <div class="modal-body">
                                <h6 class="text-center px-4">¿Está seguro de que desea borrar el curso <strong>'.$course['title'].'</strong>?</h6>
                                </div>
                                <div class="modal-footer border-0">
                                <div class="container-fluid">
                                <div class="row">
                                <div class="col-3 offset-2">
                                <button type="button" class="btn cpBtn color-deep-blue border-deep-blue px-4" data-dismiss="modal"><strong>Cancelar</strong></button>
                                </div>
                                <div class="col-3 offset-1">
                                <button type="submit" class="btn cpBtn bg-deep-blue text-white border-deep-blue px-4"><strong>Aceptar</strong></button>
                                </div>
                                </div>
                                </div>
                                </div>
                                </div>
                                </div>
                                </form>
                                </div>
                                <script type="text/javascript" id="courseEditScript'.$course['id'].'">
                                    $(window).on("load", function(){
                                         $("#courseEditImage'.$course['id'].'").fileinput({
                                            theme: "explorer",
                                            uploadUrl: "'.url('uploadImage/'.$course['id'].'/course').'",
                                            allowedFileExtensions: ["jpg", "jpeg", "png", "gif"],
                                            maxFileCount: 1,
                                            initialPreview: ["'.asset("images/uploads/".$course['image']).'"],
                                            overwriteInitial: true,
                                            initialPreviewAsData: true,
                                            maxFileSize: 10000,
                                        });

                                        $("#editCourseSubmit'.$course['id'].'").on("click", function(e){
                                            let requiredFields = $("#editCourseForm'.$course['id'].'").find("[required]");

                                            requiredFields.each(function (index, value) {
                                               if($(value).val().length < 1) {
                                                   e.preventDefault();

                                                   $("[href=\'#"+$(value).closest(".tab-pane").attr("id")+"\']").trigger("click");

                                                   setTimeout(function () {
                                                       $(value).focus();
                                                   }, 200);
                                                   return false;
                                               }
                                            });
                                        });

                                        textEditorFromReference("#courseEditDescription'.$course['id'].'");
                                        textEditorFromReference("#courseEditTeacherDescription'.$course['id'].'");
                                        textEditorFromReference("#courseEditRequirements'.$course['id'].'");
                                        $("#courseEditInitDate'.$course['id'].'").datepicker();
                                        $("#courseEditEndDate'.$course['id'].'").datepicker();
                                        $("#editModules'.$course['id'].'").accordion({
                                             header: ".module",
                                             active: 3,
                                             collapsible: true,
                                             heightStyle: "content",
                                        });
                                        $("#courseEditScript'.$course['id'].'").remove();
                                    });
                                </script>';
                        }
                    }
                ?>
            </div>
        </div>
    </div>
</div>

<!-- E N D   A D M I N I S T R A T E   C O U R S E S -->

<script id="previewScript" type="text/javascript">
    $(window).on('load', function () {
        let previewUrl = "<?php echo url('/').'/courses' ?>";
        $('.previewAnchor').attr('href', previewUrl);
        $('#previewScript').remove();
    })
</script>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>

<?php echo $__env->make('adminLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Fuerteventura2000\resources\views/administrateCourses.blade.php ENDPATH**/ ?>