<?php $__env->startSection('header'); ?>
<?php $__env->startSection('title'); ?><?php echo $course['title']; ?> - Fuerteventura2000 <?php $__env->stopSection(); ?>
<?php $__env->startSection('description'); ?><?php echo substr(strip_tags($course['description']), 0, 151).'...'; ?> <?php $__env->stopSection(); ?>
<?php $__env->startSection('img'); ?><?php echo e(asset('images/uploads/'.$course['image'])); ?> <?php $__env->stopSection(); ?>
<?php $__env->startSection('keyword'); ?><?php
    echo $course['sector'].', '.$course['type'].', '.$course['location'].', '.$course['onSite'].', ';
    if($course['level']) echo 'Nivel '.$course['level'].', ';
    if($course['type'] == 'Gratuito') echo $course['receiver'].', ';
    if($course['hours']) echo $course['hours'].' horas, ';
    if($course['teacher']) echo $course['teacher'].', ';

foreach ($course['modules'] as $module){
    echo $module[0]['code'].', '.$module[0]['title'].', ';

    foreach ($module[1] as $unit){
        echo $unit['code'].', '.$unit['title'].', ';
    }
}

foreach ($course['professionalDepartures'] as $professionalDeparture){
    echo $professionalDeparture.', ';
}

?><?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<!-- G E N E R I C   H E A D -->

<div id="genericHead">
    <img alt="<?php echo $course['imageAlt'] ?>" class="w-100 h-75" src="<?php echo e(asset('images/uploads/'.$course['image'])); ?>">
    <div class="layer"></div>
</div>

<!-- E N D   G E N E R I C   H E A D -->

<!-- C O U R S E   D A T A -->

<div id="courseData" class="overlapTop" style=>
    <div class="container-fluid">
        <div class="row">
            <div class="col-xl-8 offset-xl-2 col-lg-10 offset-lg-1 col-12 offset-0">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-8 col-12 px-sm-2 px-0">
                            <div class="w-100 bg-grey rounded shadow py-md-5 py-4 d-flex">
                                <div class="container-fluid px-sm-5 px-4 align-items-center">
                              <!-- <div class="row">
                                       <div class="col-12 mb-4">
                                           <strong class="bg-deep-blue text-white rounded py-2 px-4 d-inline-block"><?php echo $course['sector']; ?></strong>
                                       </div>
                                   </div>-->
                                    <div class="row">
                                        <div class="col-12">
                                            <h2 class="color-slate-blue"><strong>Instituto MBA Turismo</strong></h2>
                                        </div>
                                    </div>
                                    <div class="row mt-3">
                                       
                                        <div class="col-12 d-flex">
                                            <p class="color-slate-blue mr-4 mb-0">Teléfono: 699511741</p>

                                            
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 col-12 mb-md-0 mb-5 px-md-2 px-0">
                            <div class="w-100 h-100 bg-deep-blue rounded shadow d-flex align-items-center py-md-0 py-4 mt-md-0 mt-4">
                                <span class="w-100">
                                <button class="btn border-white centerHorizontal text-white noScriptDisplayNone px-4" data-toggle="modal" data-target="#courseInscriptionModal" ><strong>Preinscríbete</strong></button>
                                <noscript>
                                    <a href="#courseInscriptionModal"><button class="btn border-white centerHorizontal text-white px-4"><strong>Preinscríbete</strong></button></a>
                                </noscript>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="courseInscriptionModal" tabindex="-1" role="dialog" aria-labelledby="Modal for user inscription" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <form method="post" action="<?php echo e(url('courseInscription/'.$course['id'])); ?>">
            <?php echo e(csrf_field()); ?>

                <input class="HPInput" type="email" name="HPInput">
                <input type="hidden" name="course" value="<?php echo e($course['id']); ?>">
                <div class="modal-header border-0">
                    <h5 class="modal-title w-100 text-center color-deep-blue">Preinscríbete en <strong><?php echo e($course['title']); ?></strong></h5>
                    <button type="button" class="close noScriptDisplayNone" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                    <noscript>
                        <a href="<?php echo e(url()->full()); ?>">
                            <button type="button" class="close" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </a>
                    </noscript>
                </div>
                <div class="modal-body px-5">
                    <label for="inscriptionName" class="color-deep-blue"><h6 title="Este campo es obligatorio">Nombre<span class="text-danger">*</span></h6></label>
                    <input id="inscriptionName" class="form-control mb-2" type="text" name="name" required>
                    <label for="inscriptionEmail" class="color-deep-blue"><h6 title="Este campo es obligatorio">Email<span class="text-danger">*</span></h6></label>
                    <input id="inscriptionEmail" class="form-control mb-2" type="email" name="email" required>
                    <label for="inscriptionPhone" class="color-deep-blue"><h6 title="Este campo es obligatorio">Teléfono<span class="text-danger">*</span></h6></label>
                    <input id="inscriptionPhone" class="form-control mb-2" type="number" min="1" max="999999999999999" name="phone" required>
                    <div class="form-check mt-3">
                        <input class="form-check-input" type="checkbox" name="consent" id="inscriptionConsent" required>
                        <label class="form-check-label" for="inscriptionConsent"><h6 title="Este campo es obligatorio" class="color-deep-blue ml-1">Consiento el uso de mis datos para los fines indicados en la <a target="_blank" href="<?php echo e(url('privacyPolicy')); ?>"><u>política de privacidad</u></a>.<span class="text-danger">*</span></h6></label>
                    </div>
                    <div class="form-check mt-1">
                        <input class="form-check-input" type="checkbox" name="publicity" id="inscriptionPublicity">
                        <label class="form-check-label" for="inscriptionPublicity"><h6 title="Este campo es opcional" class="color-deep-blue ml-1">Quiero recibir ofertas y noticias de su entidad.</h6></label>
                    </div>
                </div>
                <div class="modal-footer border-0">
                    <button type="button" class="btn cpBtn color-deep-blue border-deep-blue px-4 noScriptDisplayNone toggleGeneric" data-dismiss="modal"><strong>Cancelar</strong></button>
                    <noscript>
                        <a href="<?php echo e(url()->full()); ?>"><button type="button" class="btn cpBtn color-deep-blue border-deep-blue px-4 toggleGeneric" ><strong>Cancelar</strong></button></a>
                    </noscript>
                    <button type="submit" class="btn cpBtn bg-deep-blue text-white border-deep-blue px-4 toggleContent" ><strong>Enviar</strong></button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- E N D   C O U R S E   D A T A -->

<!-- C O U R S E   D E S C R I P T I O N -->

<div class="moveTop mt0-tablet-mobile">
            <div class="container-fluid mb-5">
            <div class="row">
            <div class="col-xl-10 offset-xl-1 col-12 offset-0 px-md-5 px-0">
            <div class="d-flex mb-5">
            <h1 class="color-slate-blue w-xs-100 text-xs-center noWrap pr-4"><strong>¿Qué es?</strong></h1>
            <hr class="titleHr w-100 mt-5">
            </div>
            <div class="container-fluid">
            <div class="row">
            <div class="col-xl-10 offset-xl-1 col-12 offset-0">';
                <p class="color-slate-blue">El MBA Turismo es un Máster Executive que se organiza en las islas de Gran Canaria, Tenerife, Lanzarote y Fuerteventura. 
                Es una formación de capacitación profesional dividida en dos niveles fuertemente basados en la práctica y cuyos contenidos serán siempre impartidos por profesionales que están actualmente trabajando en el sector.
                </p>
            </div>
            </div>
            </div>
            </div>
            </div>
            </div>
            </div>
    

?>

<!-- E N D   C O U R S E   D E S C R I P T I O N -->

<!-- C O U R S E   T E A C H E R -->

<div id="teacher">
            <div class="container-fluid mb-5">
            <div class="row">
            <div class="col-xl-10 offset-xl-1 col-12 offset-0 px-md-5 px-0">
            <div class="d-flex mb-5">
            <h1 class="color-slate-blue w-xs-100 text-xs-center noWrap pr-4"><strong>¿A quién va dirigido?</strong></h1>
            <hr class="titleHr w-100 mt-5">
            </div>
            <div class="container-fluid">
            <div class="row">
            <div class="col-xl-10 offset-xl-1 col-12 offset-0">
            <p>El máster está dirigido a directivos, mandos intermedios y emprendedores que quieran mejorar su formación en el sector y ver mejoradas sus competencias profesionales. 
Como resumen, el máster va dirigido a:</p>
<li>
    <ul>
        Directores y propietarios de hoteles.
    </ul>
    <ul>
        Mandos intermedios: directores de operaciones, finanzas y recursos humanos subdirectores de hotel; jefes de recepción; jefes de departamento.
    </ul>
    <ul>
        Empresarios del sector de la restauración y el ocio.
    </ul>
    <ul>
        Técnicos de la administración.
    </ul>
    <ul>
        Licenciados que quieran especializarse en el sector turístico.
    </ul>
</li>

        </div>
            </div>
            </div>
            </div>
            </div>
            </div>
            </div>




<!-- E N D   C O U R S E   T E A C H E R -->


<!-- C O N T E N T -->

<div id="courseContent">
                <div class="container-fluid mb-5">
                <div class="row">
                <div class="col-xl-10 offset-xl-1 col-12 offset-0 px-md-5 px-0">
                <div class="d-flex mb-5">
                <h1 class="color-slate-blue w-xs-100 text-xs-center noWrap pr-4"><strong>Contenido</strong></h1>
                <hr class="titleHr w-100 mt-5">
                </div>
                <div class="container-fluid">
                    <div class="row">
                <div class="col-xl-10 offset-xl-1 col-12 offset-0">
                    Las diferentes áreas de capacitación van desde gestión de recursos humanos, 
                    a dirección financiera, pasando por estrategia, operaciones o marketing digital, divididos en
                    2 programas, un programa superior de Septiembre a Diciembre, y un programa Experto de Abril a Julio. 
                    </div>
                    </div>
                <div class="row">
                <div class="col-xl-10 offset-xl-1 col-12 offset-0">
                    
                    

                <div class="bg-grey rounded accordionHead mt-2">
                    <div class="container-fluid">
                    <div class="row align-items-center py-3 px-1">
                    <div class="col-10">
                    <h4 class="color-slate-blue"><strong>Programa Superior</strong></h4><h4 class="color-slate-blue">';
                    </h4></div>
                    <div class="col-2">

                    <i title="Ver más" class="glyphicon glyphicon-plus float-right color-slate-blue d-inline"></i>
                              <i title="Ver menos" class="glyphicon glyphicon-minus float-right color-slate-blue d-none"></i>

                    </div>
                    </div>
                    </div>
                    </div>
                    <div class="accordionBody mb-2 px-2">';
                    
                    
                        <div class="container-fluid mt-2">
                            <div class="row">
                                <div class="col-10 px-md-2 p-0">
                                    <h4 class="color-slate-blue">
                                        <strong>Dirección Estratégica.</strong>
                                    </h4>
                                </div>
                        
                            </div>
                          </div>
                          
                          <div class="container-fluid mt-2">
                            <div class="row">
                                <div class="col-10 px-md-2 p-0">
                                    <h4 class="color-slate-blue">
                                        <strong>Dirección Operaciones I.</strong>
                                    </h4>
                                </div>
                            </div>
                          </div>
                          
                          <div class="container-fluid mt-2">
                            <div class="row">
                                <div class="col-10 px-md-2 p-0">
                                    <h4 class="color-slate-blue">
                                        <strong>Técnicas de Negociación.</strong>
                                    </h4>
                                </div>
                            </div>
                          </div>
                          
                          <div class="container-fluid mt-2">
                            <div class="row">
                                <div class="col-10 px-md-2 p-0">
                                    <h4 class="color-slate-blue">
                                        <strong>Finanzas.</strong>
                                    </h4>
                                </div>
                            </div>
                          </div>
                          
                          <div class="container-fluid mt-2">
                            <div class="row">
                                <div class="col-10 px-md-2 p-0">
                                    <h4 class="color-slate-blue">
                                        <strong>Marketing.</strong>
                                    </h4>
                                </div>
                            </div>
                          </div>
                          
                          <div class="container-fluid mt-2">
                            <div class="row">
                                <div class="col-10 px-md-2 p-0">
                                    <h4 class="color-slate-blue">
                                        <strong>MICE.</strong>
                                    </h4>
                                </div>
                            </div>
                          </div>
                          
                          <div class="container-fluid mt-2">
                            <div class="row">
                                <div class="col-10 px-md-2 p-0">
                                    <h4 class="color-slate-blue">
                                        <strong>Dirección de Personas.</strong>
                                    </h4>
                                </div>
                            </div>
                          </div>
                          
                          <div class="container-fluid mt-2">
                            <div class="row">
                                <div class="col-10 px-md-2 p-0">
                                    <h4 class="color-slate-blue">
                                        <strong>Digital Business.</strong>
                                    </h4>
                                </div>
                            </div>
                          </div>
                          
                          <div class="container-fluid mt-2">
                            <div class="row">
                                <div class="col-10 px-md-2 p-0">
                                    <h4 class="color-slate-blue">
                                        <strong>Entorno Jurídico.</strong>
                                    </h4>
                                </div>
                            </div>
                          </div>
                          
                          <div class="container-fluid mt-2">
                            <div class="row">
                                <div class="col-10 px-md-2 p-0">
                                    <h4 class="color-slate-blue">
                                        <strong>Comunicación Directiva.</strong>
                                    </h4>
                                </div>
                            </div>
                          </div>
                          
                          <div class="container-fluid mt-2">
                            <div class="row">
                                <div class="col-10 px-md-2 p-0">
                                    <h4 class="color-slate-blue">
                                        <strong>Seminarios y Conferencias.</strong>
                                    </h4>
                                </div>
                            </div>
                          </div>
                          

                </div>
                
                
                <div class="bg-grey rounded accordionHead mt-2">
                    <div class="container-fluid">
                    <div class="row align-items-center py-3 px-1">
                    <div class="col-10">
                    <h4 class="color-slate-blue"><strong>Programa Experto</strong></h4><h4 class="color-slate-blue">';
                    </h4></div>
                    <div class="col-2">

                    <i title="Ver más" class="glyphicon glyphicon-plus float-right color-slate-blue d-inline"></i>
                              <i title="Ver menos" class="glyphicon glyphicon-minus float-right color-slate-blue d-none"></i>

                    </div>
                    </div>
                    </div>
                    </div>
                    <div class="accordionBody mb-2 px-2">';
                    
                    
                        <div class="container-fluid mt-2">
                            <div class="row">
                                <div class="col-10 px-md-2 p-0">
                                    <h4 class="color-slate-blue">
                                        <strong>Análisis Financiero.</strong>
                                    </h4>
                                </div>
                        
                            </div>
                          </div>
                          
                          <div class="container-fluid mt-2">
                            <div class="row">
                                <div class="col-10 px-md-2 p-0">
                                    <h4 class="color-slate-blue">
                                        <strong>Dirección Operaciones I.</strong>
                                    </h4>
                                </div>
                            </div>
                          </div>
                          
                          <div class="container-fluid mt-2">
                            <div class="row">
                                <div class="col-10 px-md-2 p-0">
                                    <h4 class="color-slate-blue">
                                        <strong>Gestión de la Innovación.</strong>
                                    </h4>
                                </div>
                            </div>
                          </div>
                          
                          <div class="container-fluid mt-2">
                            <div class="row">
                                <div class="col-10 px-md-2 p-0">
                                    <h4 class="color-slate-blue">
                                        <strong>Food & Beverage.</strong>
                                    </h4>
                                </div>
                            </div>
                          </div>
                          
                          <div class="container-fluid mt-2">
                            <div class="row">
                                <div class="col-10 px-md-2 p-0">
                                    <h4 class="color-slate-blue">
                                        <strong>Dirección de Ventas.</strong>
                                    </h4>
                                </div>
                            </div>
                          </div>
                          
                          <div class="container-fluid mt-2">
                            <div class="row">
                                <div class="col-10 px-md-2 p-0">
                                    <h4 class="color-slate-blue">
                                        <strong>Dirección Operaciones II.</strong>
                                    </h4>
                                </div>
                            </div>
                          </div>
                          
                          <div class="container-fluid mt-2">
                            <div class="row">
                                <div class="col-10 px-md-2 p-0">
                                    <h4 class="color-slate-blue">
                                        <strong>Canal Directo.</strong>
                                    </h4>
                                </div>
                            </div>
                          </div>
                          
                          <div class="container-fluid mt-2">
                            <div class="row">
                                <div class="col-10 px-md-2 p-0">
                                    <h4 class="color-slate-blue">
                                        <strong>Gestión de Equipos.</strong>
                                    </h4>
                                </div>
                            </div>
                          </div>
                          
                          <div class="container-fluid mt-2">
                            <div class="row">
                                <div class="col-10 px-md-2 p-0">
                                    <h4 class="color-slate-blue">
                                        <strong>Proyecto Final.</strong>
                                    </h4>
                                </div>
                            </div>
                          </div>
               
                          

                </div>


                </div>
                </div>
                </div>
                </div>
                </div>
                </div>
                </div>

<!-- E N D   C O N T E N T -->

<!-- R E Q U I R E M E N T S -->

<div id="requirements">
            <div class="container-fluid mb-5">
            <div class="row">
            <div class="col-xl-10 offset-xl-1 col-12 offset-0 px-md-5 px-0">
            <div class="d-flex mb-5">
            <h1 class="color-slate-blue w-xs-100 text-xs-center noWrap pr-4"><strong>¿Dónde se imparte?</strong></h1>
            <hr class="titleHr w-100 mt-5">
            </div>
            <div class="container-fluid">
            <div class="row">
            <div class="col-xl-10 offset-xl-1 col-12 offset-0">';
            
            <strong>Tenerife</strong>
            <li>
                <ul><strong>HORARIO</strong>: Lunes y miércoles, de 16:30 a 20:45</ul>
                <ul><strong>UBICACIÓN</strong>: Mare Nostrum Resort (Playa de las Américas).</ul>
                <ul><strong>FECHAS</strong>: el Programa Superior comenzará el 14 de septiembre y finalizará el 14 de diciembre de 2020. El Programa Experto tendrá lugar a principios de abril hasta principios de julio de 2021.</ul>
            </li>
            <strong>Gran Canaria</strong>
            <li>
                <ul><strong>HORARIO</strong>: Lunes y miércoles, de 16:30 a 20:45</ul>
                <ul><strong>UBICACIÓN</strong>: Hotel Meliá Tamarindos (San Agustín).</ul>
                <ul><strong>FECHAS</strong>: el Programa Superior comenzará el 16 de septiembre y finalizará el 16 de diciembre de 2020. El Programa Experto tendrá lugar a principios de abril hasta principios de julio de 2021.</ul>
            </li>
            <strong>Lanzarote</strong>
            <li>
                <ul><strong>HORARIO</strong>: Lunes y Jueves, de 15:45 a 19:45</ul>
                <ul><strong>UBICACIÓN</strong>: Lava Beach Hotel (Puerto del Carmen).</ul>
                <ul><strong>FECHAS</strong>: el Programa Superior comenzará el 17 de septiembre y finalizará el 17 de diciembre de 2020. El Programa Experto tendrá lugar a principios de abril hasta principios de julio de 2021.</ul>
            </li>
            <strong>Fuerteventura</strong>
            <li>
                <ul><strong>HORARIO</strong>: Martes y Jueves, de 16:00 a 20:00.</ul>
                <ul><strong>UBICACIÓN</strong>: Hotel Barceló Fuerteventura Thalasso Spa (Caleta de Fuste).</ul>
                <ul><strong>FECHAS</strong>: el Programa Superior comenzará el 15 de septiembre y finalizará el 15 de diciembre de 2020. El Programa Experto tendrá lugar a principios de abril hasta principios de julio de 2021.</ul>
            </li>

       </div>
            </div>
            </div>
            </div>
            </div>
            </div>
            </div>



<!-- E N D   R E Q U I R E M E N T S -->

<!-- D I S C O V E R   U S -->

<div id="discoverUs">
    <div class="container-fluid">
        <div class="row position-relative z-index-0">
            <div class="w-100 z-index-0">
                <img class="w-100 h-400" alt="<?php echo e($course['imageAlt']); ?>" src="<?php echo e(asset('images/uploads/'.$course['image'])); ?>">
                <div class="textBox absoluteCenterBoth w-md-75 w-xs-100 px-sm-0 px-3">
                    <h4 class="text-center text-white font-weight-light">Curso
                        <?php

                        if($course['type'] == 'Gratuito') echo 'para '.$course['receiver'];
                        else echo $course['type'];

                        if($course['level']) echo ' de nivel '.$course['level'];

                        ?>
                    </h4>
                    <h1 class="text-white text-center clamp"><?php echo $course['title'] ?></h1>
                    <h4 class="text-center text-white font-weight-light mb-5">
                        <?php

                        echo $course['location'].' '.$course['onSite'].' ';
                        if($course['hours']) echo $course['hours'].' Horas</p>';

                        ?>
                    </h4>
                </div>
                <div class="layer"></div>
            </div>
        </div>
        <div class="accessBox bg-deep-blue rounded w-50 w-md-75 w-xs-100 shadow">
            <div class="container-fluid">
                <div class="row align-items-center py-md-5 py-4 px-md-0 px-2">
                    <div class="col-md-6 offset-md-1 px-lg-4 px-md-0">
                        <p class="text-white">Matrícula abierta. Plazas limitadas. <br> ¡Solicita ya tu plaza sin compromiso!</p>
                    </div>
                    <div class="col-xl-3 offset-xl-1 col-md-4 offset-md-1">
                        <button class="btn border-white text-white px-4 noScriptDisplayNone centerHorizontal" data-toggle="modal" data-target="#courseInscriptionModal"><strong>Preinscríbete</strong></button>
                        <noscript>
                            <a href="#courseInscriptionModal"><button class="btn border-white text-white centerHorizontal px-4"><strong>Preinscríbete</strong></button></a>
                        </noscript>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- E N D   D I S C O V E R   U S -->

<!-- N E W S -->

<div id="news">
    <div class="container-fluid mb-6">
        <div class="row">
            <div class="col-xl-10 offset-xl-1 col-12 offset-0 px-md-5 px-0">
                <div class="d-flex mb-5">
                    <h1 class="color-slate-blue w-xs-100 text-xs-center noWrap pr-sm-4 pr-0"><strong>Noticias</strong></h1>
                    <hr class="titleHr w-100 mt-5">
                </div>
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-xl-10 offset-xl-1 col-12 offset-0">
                            <div class="container-fluid">
                                <div class="row mb-5">
                                    <div id="mobileNewsSwiper" class="swiper-container d-md-inline-block d-lg-none">
                                        <div class="swiper-wrapper">
                                            <?php

                                            foreach ($news as $new){
                                                echo '<div class="swiper-slide">
                                            <div class="col-12">
                                            <a href="'.url('new/'.$new['title'].'?key='.$new['id']).'">
                                            <div class="w-100 rounded shadow new">
                                            <img alt="'.$new['imageAlt'].'" class="w-100 h-100 swiper-lazy" data-src="'.asset('images/uploads/'.$new['image']).'">
                                            <div class="swiper-lazy-preloader"></div>
                                            <h5 class="text-white"><strong>'.$new['title'].'</strong></h5>
                                            <div class="layer"></div>
                                            </div>
                                            </a>
                                            </div>
                                            </div>';
                                            }

                                            echo '</div></div>';

                                            $first = true;

                                            foreach ($news as $new){
                                                echo '<div class="d-lg-inline-block d-none ';

                                                if($first) echo 'col-lg-6 col-md-4 col-sm-6';
                                                else echo 'col-lg-3 col-md-4 col-6';

                                                echo '">
                                            <a href="'.url('new/'.$new['title'].'?key='.$new['id']).'">
                                            <div class="w-100 rounded shadow new">
                                            <img alt="'.$new['imageAlt'].'" class="w-100 h-100" src="'.asset('images/uploads/'.$new['image']).'">
                                            <h5 class="text-white"><strong>'.$new['title'].'</strong></h5>
                                            <div class="layer"></div>
                                            </div>
                                            </a>
                                            </div>';
                                                $first = false;
                                            }

                                            ?>
                                    </div>
                                <a href="<?php echo e(url('news')); ?>"><button class="btn color-deep-blue border-deep-blue centerHorizontal px-4"><strong class="noWrap">Más noticias</strong></button></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- E N D   N E W S -->

<script type="text/javascript" src="<?php echo e(asset('js/course.js')); ?>"></script>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/zb3f46kb/projects_data/fuerteventura2000_data/resources/views/master.blade.php ENDPATH**/ ?>