<?php $__env->startSection('header'); ?>
<?php $__env->startSection('title'); ?>Cuestionario de calidad - Fuerteventura2000 <?php $__env->stopSection(); ?>
<?php $__env->startSection('description'); ?> Fuerteventura2000 ofrece un cuestionario de calidad sobre nuestros cursos para saber más acerca de la calidad de nuestros servicios. <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="container-fluid mt-6 mb-6 pt-5">
    <form id="questionnaire" method="post" action="<?php echo e(url('sendEvaluation')); ?>">
        <?php echo e(csrf_field()); ?>

        <div class="row">
            <div class="col-xl-10 offset-xl-1 col-12 offset-0 px-xl-0 px-lg-5">
                <div class="d-flex mb-2">
                    <h1 class="color-slate-blue w-xs-100 text-xs-center noWrap pr-sm-4 pr-0"><strong>Cuestionario de Calidad</strong></h1>
                    <hr class="titleHr w-100 mt-5">
                </div>
                <h5 class="color-deep-blue mb-5"><?php echo e($course); ?></h5>
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-3 col-12">
                            <div class="form-group mb-0">
                                <label title="Este campo es obligatorio" for="userAge" class="color-deep-blue font-weight-bold">Edad<span class="text-danger"> *</span></label>
                                <input type="number" class="form-control" id="userAge" name="age" autocomplete="off" required>
                            </div>
                        </div>
                        <div class="col-md-6 col-12">
                            <label title="Este campo es obligatorio" class="d-block color-deep-blue font-weight-bold">Género<span class="text-danger"> *</span></label>
                            <div class="radio d-inline">
                                <label>
                                    <input type="radio" name="gender" value="Masculino" required>
                                    <strong> Masculino</strong>
                                </label>
                            </div>
                            <div class="radio d-inline ml-4">
                                <label>
                                    <input type="radio" name="gender" value="Femenino" required>
                                    <strong> Femenino</strong>
                                </label>
                            </div>
                        </div>
                    </div>
                    <div class="row mt-5">
                        <div class="col-12">
                            <h5>
                                Valore de <strong>0 (Muy en desacuerdo)</strong> a <strong>10 (Muy de acuerdo)</strong> las siguientes cuestiones.<br>
                                Por favor, le rogamos responda a todas y cada una de las preguntas de este cuestionario. <strong>Muchas gracias por su colaboración.</strong>
                            </h5>
                        </div>
                    </div>
                </div>
                <div class="container-fluid section mt-5">
                    <div class="row">
                        <div class="col-12"><h5 class="color-deep-blue font-weight-bold"><u>VALORACIÓN GENERAL DEL CURSO</u></h5></div>
                    </div>
                    <div class="row mt-4">
                        <div class="col-xl-5 col-lg-6 col-md-12"><h6 class="absoluteToBottom p-md-static mb-lg-5 mb-0 question"><strong class="color-deep-blue">1)</strong> El curso/acción formativa ha satisfecho mis expectativas.</h6></div>
                        <div class="col-xl-7 col-lg-6 col-md-12 px-0">
                            <table class="table table-bordered exclude mt-lg-0 mt-4">
                                <thead>
                                <tr>
                                    <th class="p-md-2 p-0 text-center">0</th>
                                    <th class="p-md-2 p-0 text-center">1</th>
                                    <th class="p-md-2 p-0 text-center">2</th>
                                    <th class="p-md-2 p-0 text-center">3</th>
                                    <th class="p-md-2 p-0 text-center">4</th>
                                    <th class="p-md-2 p-0 text-center">5</th>
                                    <th class="p-md-2 p-0 text-center">6</th>
                                    <th class="p-md-2 p-0 text-center">7</th>
                                    <th class="p-md-2 p-0 text-center">8</th>
                                    <th class="p-md-2 p-0 text-center">9</th>
                                    <th class="p-md-2 p-0 text-center">10</th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr>
                                    <td class="p-md-2 p-0 text-center" data-value="0"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                    <td class="p-md-2 p-0 text-center" data-value="1"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                    <td class="p-md-2 p-0 text-center" data-value="2"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                    <td class="p-md-2 p-0 text-center" data-value="3"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                    <td class="p-md-2 p-0 text-center" data-value="4"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                    <td class="p-md-2 p-0 text-center" data-value="5"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                    <td class="p-md-2 p-0 text-center" data-value="6"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                    <td class="p-md-2 p-0 text-center" data-value="7"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                    <td class="p-md-2 p-0 text-center" data-value="8"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                    <td class="p-md-2 p-0 text-center" data-value="9"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                    <td class="p-md-2 p-0 text-center" data-value="10"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="row mt-4">
                        <div class="col-xl-5 col-lg-6 col-md-12"><h6 class="absoluteToBottom p-md-static mb-lg-5 mb-0 question"><strong class="color-deep-blue">2)</strong> El curso/acción formativa ha ampliado mis conocimiento y/o habilidades.</h6></div>
                        <div class="col-xl-7 col-lg-6 col-md-12 px-0">
                            <table class="table table-bordered exclude mt-lg-0 mt-4">
                                <thead>
                                <tr>
                                    <th class="p-md-2 p-0 text-center">0</th>
                                    <th class="p-md-2 p-0 text-center">1</th>
                                    <th class="p-md-2 p-0 text-center">2</th>
                                    <th class="p-md-2 p-0 text-center">3</th>
                                    <th class="p-md-2 p-0 text-center">4</th>
                                    <th class="p-md-2 p-0 text-center">5</th>
                                    <th class="p-md-2 p-0 text-center">6</th>
                                    <th class="p-md-2 p-0 text-center">7</th>
                                    <th class="p-md-2 p-0 text-center">8</th>
                                    <th class="p-md-2 p-0 text-center">9</th>
                                    <th class="p-md-2 p-0 text-center">10</th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr>
                                    <td class="p-md-2 p-0 text-center" data-value="0"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                    <td class="p-md-2 p-0 text-center" data-value="1"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                    <td class="p-md-2 p-0 text-center" data-value="2"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                    <td class="p-md-2 p-0 text-center" data-value="3"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                    <td class="p-md-2 p-0 text-center" data-value="4"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                    <td class="p-md-2 p-0 text-center" data-value="5"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                    <td class="p-md-2 p-0 text-center" data-value="6"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                    <td class="p-md-2 p-0 text-center" data-value="7"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                    <td class="p-md-2 p-0 text-center" data-value="8"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                    <td class="p-md-2 p-0 text-center" data-value="9"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                    <td class="p-md-2 p-0 text-center" data-value="10"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="row mt-4">
                        <div class="col-xl-5 col-lg-6 col-md-12"><h6 class="absoluteToBottom p-md-static mb-lg-5 mb-0 question"><strong class="color-deep-blue">3)</strong> Me ofrece posibilidades de inserción laboral.</h6></div>
                        <div class="col-xl-7 col-lg-6 col-md-12 px-0">
                            <table class="table table-bordered exclude mt-lg-0 mt-4">
                                <thead>
                                <tr>
                                    <th class="p-md-2 p-0 text-center">0</th>
                                    <th class="p-md-2 p-0 text-center">1</th>
                                    <th class="p-md-2 p-0 text-center">2</th>
                                    <th class="p-md-2 p-0 text-center">3</th>
                                    <th class="p-md-2 p-0 text-center">4</th>
                                    <th class="p-md-2 p-0 text-center">5</th>
                                    <th class="p-md-2 p-0 text-center">6</th>
                                    <th class="p-md-2 p-0 text-center">7</th>
                                    <th class="p-md-2 p-0 text-center">8</th>
                                    <th class="p-md-2 p-0 text-center">9</th>
                                    <th class="p-md-2 p-0 text-center">10</th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr>
                                    <td class="p-md-2 p-0 text-center" data-value="0"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                    <td class="p-md-2 p-0 text-center" data-value="1"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                    <td class="p-md-2 p-0 text-center" data-value="2"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                    <td class="p-md-2 p-0 text-center" data-value="3"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                    <td class="p-md-2 p-0 text-center" data-value="4"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                    <td class="p-md-2 p-0 text-center" data-value="5"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                    <td class="p-md-2 p-0 text-center" data-value="6"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                    <td class="p-md-2 p-0 text-center" data-value="7"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                    <td class="p-md-2 p-0 text-center" data-value="8"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                    <td class="p-md-2 p-0 text-center" data-value="9"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                    <td class="p-md-2 p-0 text-center" data-value="10"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="row mt-4">
                        <div class="col-xl-5 col-lg-6 col-md-12"><h6 class="absoluteToBottom p-md-static mb-lg-5 mb-0 question"><strong class="color-deep-blue">4)</strong> La valoración general del curso/acción formativa es buena.</h6></div>
                        <div class="col-xl-7 col-lg-6 col-md-12 px-0">
                            <table class="table table-bordered exclude mt-lg-0 mt-4">
                                <thead>
                                <tr>
                                    <th class="p-md-2 p-0 text-center">0</th>
                                    <th class="p-md-2 p-0 text-center">1</th>
                                    <th class="p-md-2 p-0 text-center">2</th>
                                    <th class="p-md-2 p-0 text-center">3</th>
                                    <th class="p-md-2 p-0 text-center">4</th>
                                    <th class="p-md-2 p-0 text-center">5</th>
                                    <th class="p-md-2 p-0 text-center">6</th>
                                    <th class="p-md-2 p-0 text-center">7</th>
                                    <th class="p-md-2 p-0 text-center">8</th>
                                    <th class="p-md-2 p-0 text-center">9</th>
                                    <th class="p-md-2 p-0 text-center">10</th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr>
                                    <td class="p-md-2 p-0 text-center" data-value="0"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                    <td class="p-md-2 p-0 text-center" data-value="1"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                    <td class="p-md-2 p-0 text-center" data-value="2"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                    <td class="p-md-2 p-0 text-center" data-value="3"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                    <td class="p-md-2 p-0 text-center" data-value="4"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                    <td class="p-md-2 p-0 text-center" data-value="5"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                    <td class="p-md-2 p-0 text-center" data-value="6"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                    <td class="p-md-2 p-0 text-center" data-value="7"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                    <td class="p-md-2 p-0 text-center" data-value="8"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                    <td class="p-md-2 p-0 text-center" data-value="9"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                    <td class="p-md-2 p-0 text-center" data-value="10"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="container-fluid section mt-6">
                    <div class="row">
                        <div class="col-12"><h5 class="color-deep-blue font-weight-bold"><u>ORGANIZACIÓN DEL CURSO/ACCIÓN FORMATIVA</u></h5></div>
                    </div>
                    <div class="row mt-4">
                        <div class="col-xl-5 col-lg-6 col-md-12"><h6 class="absoluteToBottom p-md-static mb-lg-5 mb-0 question"><strong class="color-deep-blue">1)</strong> La organización del curso ha sido adecuada (inscripción, entrega  de materiales, información sobre documentación a entregar, información sobre normativa, etc.).</h6></div>
                        <div class="col-xl-7 col-lg-6 col-md-12 px-0">
                            <table class="table table-bordered exclude mt-lg-0 mt-4">
                                <thead>
                                <tr>
                                    <th class="p-md-2 p-0 text-center">0</th>
                                    <th class="p-md-2 p-0 text-center">1</th>
                                    <th class="p-md-2 p-0 text-center">2</th>
                                    <th class="p-md-2 p-0 text-center">3</th>
                                    <th class="p-md-2 p-0 text-center">4</th>
                                    <th class="p-md-2 p-0 text-center">5</th>
                                    <th class="p-md-2 p-0 text-center">6</th>
                                    <th class="p-md-2 p-0 text-center">7</th>
                                    <th class="p-md-2 p-0 text-center">8</th>
                                    <th class="p-md-2 p-0 text-center">9</th>
                                    <th class="p-md-2 p-0 text-center">10</th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr>
                                      <td class="p-md-2 p-0 text-center" data-value="0"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="1"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="2"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="3"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="4"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="5"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="6"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="7"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="8"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="9"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="10"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="row mt-4">
                        <div class="col-xl-5 col-lg-6 col-md-12"><h6 class="absoluteToBottom p-md-static mb-lg-5 mb-0 question"><strong class="color-deep-blue">2)</strong> El horario del curso/acción formativa ha sido apropiado.</h6></div>
                        <div class="col-xl-7 col-lg-6 col-md-12 px-0">
                            <table class="table table-bordered exclude mt-lg-0 mt-4">
                                <thead>
                                <tr>
                                    <th class="p-md-2 p-0 text-center">0</th>
                                    <th class="p-md-2 p-0 text-center">1</th>
                                    <th class="p-md-2 p-0 text-center">2</th>
                                    <th class="p-md-2 p-0 text-center">3</th>
                                    <th class="p-md-2 p-0 text-center">4</th>
                                    <th class="p-md-2 p-0 text-center">5</th>
                                    <th class="p-md-2 p-0 text-center">6</th>
                                    <th class="p-md-2 p-0 text-center">7</th>
                                    <th class="p-md-2 p-0 text-center">8</th>
                                    <th class="p-md-2 p-0 text-center">9</th>
                                    <th class="p-md-2 p-0 text-center">10</th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr>
                                      <td class="p-md-2 p-0 text-center" data-value="0"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="1"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="2"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="3"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="4"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="5"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="6"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="7"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="8"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="9"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="10"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="row mt-4">
                        <div class="col-xl-5 col-lg-6 col-md-12"><h6 class="absoluteToBottom p-md-static mb-lg-5 mb-0 question"><strong class="color-deep-blue">3)</strong> La duración del curso/acción formativa permite cumplir los objetivos.</h6></div>
                        <div class="col-xl-7 col-lg-6 col-md-12 px-0">
                            <table class="table table-bordered exclude mt-lg-0 mt-4">
                                <thead>
                                <tr>
                                    <th class="p-md-2 p-0 text-center">0</th>
                                    <th class="p-md-2 p-0 text-center">1</th>
                                    <th class="p-md-2 p-0 text-center">2</th>
                                    <th class="p-md-2 p-0 text-center">3</th>
                                    <th class="p-md-2 p-0 text-center">4</th>
                                    <th class="p-md-2 p-0 text-center">5</th>
                                    <th class="p-md-2 p-0 text-center">6</th>
                                    <th class="p-md-2 p-0 text-center">7</th>
                                    <th class="p-md-2 p-0 text-center">8</th>
                                    <th class="p-md-2 p-0 text-center">9</th>
                                    <th class="p-md-2 p-0 text-center">10</th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr>
                                      <td class="p-md-2 p-0 text-center" data-value="0"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="1"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="2"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="3"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="4"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="5"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="6"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="7"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="8"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="9"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="10"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <div class="container-fluid section mt-6">
                    <div class="row">
                        <div class="col-12"><h5 class="color-deep-blue font-weight-bold"><u>CONTENIDOS DEL CURSO/ACCIÓN FORMATIVA</u></h5></div>
                    </div>
                    <div class="row mt-4">
                        <div class="col-xl-5 col-lg-6 col-md-12"><h6 class="absoluteToBottom p-md-static mb-lg-5 mb-0 question"><strong class="color-deep-blue">1)</strong> El curso/ acción formativa tiene una combinación adecuada de contenidos teóricos y prácticos.</h6></div>
                        <div class="col-xl-7 col-lg-6 col-md-12 px-0">
                            <table class="table table-bordered exclude mt-lg-0 mt-4">
                                <thead>
                                <tr>
                                    <th class="p-md-2 p-0 text-center">0</th>
                                    <th class="p-md-2 p-0 text-center">1</th>
                                    <th class="p-md-2 p-0 text-center">2</th>
                                    <th class="p-md-2 p-0 text-center">3</th>
                                    <th class="p-md-2 p-0 text-center">4</th>
                                    <th class="p-md-2 p-0 text-center">5</th>
                                    <th class="p-md-2 p-0 text-center">6</th>
                                    <th class="p-md-2 p-0 text-center">7</th>
                                    <th class="p-md-2 p-0 text-center">8</th>
                                    <th class="p-md-2 p-0 text-center">9</th>
                                    <th class="p-md-2 p-0 text-center">10</th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr>
                                      <td class="p-md-2 p-0 text-center" data-value="0"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="1"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="2"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="3"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="4"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="5"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="6"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="7"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="8"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="9"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="10"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="row mt-4">
                        <div class="col-xl-5 col-lg-6 col-md-12"><h6 class="absoluteToBottom p-md-static mb-lg-5 mb-0 question"><strong class="color-deep-blue">2)</strong> Los contenidos del curso/ acción formativa responden a mis necesidades de formación.</h6></div>
                        <div class="col-xl-7 col-lg-6 col-md-12 px-0">
                            <table class="table table-bordered exclude mt-lg-0 mt-4">
                                <thead>
                                <tr>
                                    <th class="p-md-2 p-0 text-center">0</th>
                                    <th class="p-md-2 p-0 text-center">1</th>
                                    <th class="p-md-2 p-0 text-center">2</th>
                                    <th class="p-md-2 p-0 text-center">3</th>
                                    <th class="p-md-2 p-0 text-center">4</th>
                                    <th class="p-md-2 p-0 text-center">5</th>
                                    <th class="p-md-2 p-0 text-center">6</th>
                                    <th class="p-md-2 p-0 text-center">7</th>
                                    <th class="p-md-2 p-0 text-center">8</th>
                                    <th class="p-md-2 p-0 text-center">9</th>
                                    <th class="p-md-2 p-0 text-center">10</th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr>
                                      <td class="p-md-2 p-0 text-center" data-value="0"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="1"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="2"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="3"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="4"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="5"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="6"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="7"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="8"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="9"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="10"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="row mt-4">
                        <div class="col-xl-5 col-lg-6 col-md-12"><h6 class="absoluteToBottom p-md-static mb-lg-5 mb-0 question"><strong class="color-deep-blue">3)</strong> Los contenidos me ofrecen posibilidades de desarrollo profesional o personal.</h6></div>
                        <div class="col-xl-7 col-lg-6 col-md-12 px-0">
                            <table class="table table-bordered exclude mt-lg-0 mt-4">
                                <thead>
                                <tr>
                                    <th class="p-md-2 p-0 text-center">0</th>
                                    <th class="p-md-2 p-0 text-center">1</th>
                                    <th class="p-md-2 p-0 text-center">2</th>
                                    <th class="p-md-2 p-0 text-center">3</th>
                                    <th class="p-md-2 p-0 text-center">4</th>
                                    <th class="p-md-2 p-0 text-center">5</th>
                                    <th class="p-md-2 p-0 text-center">6</th>
                                    <th class="p-md-2 p-0 text-center">7</th>
                                    <th class="p-md-2 p-0 text-center">8</th>
                                    <th class="p-md-2 p-0 text-center">9</th>
                                    <th class="p-md-2 p-0 text-center">10</th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr>
                                      <td class="p-md-2 p-0 text-center" data-value="0"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="1"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="2"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="3"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="4"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="5"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="6"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="7"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="8"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="9"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="10"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <div class="container-fluid section mt-6">
                    <div class="row">
                        <div class="col-12"><h5 class="color-deep-blue font-weight-bold"><u>FORMADORES-TUTORES</u></h5></div>
                    </div>
                    <div class="row mt-4">
                        <div class="col-xl-5 col-lg-6 col-md-12"><h6 class="absoluteToBottom p-md-static mb-lg-5 mb-0 question"><strong class="color-deep-blue">1)</strong> Han facilitado las relaciones interpersonales, el trabajo en grupo y resuelto las Situaciones de conflicto.</h6></div>
                        <div class="col-xl-7 col-lg-6 col-md-12 px-0">
                            <table class="table table-bordered exclude mt-lg-0 mt-4">
                                <thead>
                                <tr>
                                    <th class="p-md-2 p-0 text-center">0</th>
                                    <th class="p-md-2 p-0 text-center">1</th>
                                    <th class="p-md-2 p-0 text-center">2</th>
                                    <th class="p-md-2 p-0 text-center">3</th>
                                    <th class="p-md-2 p-0 text-center">4</th>
                                    <th class="p-md-2 p-0 text-center">5</th>
                                    <th class="p-md-2 p-0 text-center">6</th>
                                    <th class="p-md-2 p-0 text-center">7</th>
                                    <th class="p-md-2 p-0 text-center">8</th>
                                    <th class="p-md-2 p-0 text-center">9</th>
                                    <th class="p-md-2 p-0 text-center">10</th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr>
                                      <td class="p-md-2 p-0 text-center" data-value="0"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="1"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="2"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="3"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="4"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="5"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="6"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="7"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="8"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="9"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="10"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="row mt-4">
                        <div class="col-xl-5 col-lg-6 col-md-12"><h6 class="absoluteToBottom p-md-static mb-lg-5 mb-0 question"><strong class="color-deep-blue">2)</strong> La forma de impartir el curso ha propiciado mi aprendizaje.</h6></div>
                        <div class="col-xl-7 col-lg-6 col-md-12 px-0">
                            <table class="table table-bordered exclude mt-lg-0 mt-4">
                                <thead>
                                <tr>
                                    <th class="p-md-2 p-0 text-center">0</th>
                                    <th class="p-md-2 p-0 text-center">1</th>
                                    <th class="p-md-2 p-0 text-center">2</th>
                                    <th class="p-md-2 p-0 text-center">3</th>
                                    <th class="p-md-2 p-0 text-center">4</th>
                                    <th class="p-md-2 p-0 text-center">5</th>
                                    <th class="p-md-2 p-0 text-center">6</th>
                                    <th class="p-md-2 p-0 text-center">7</th>
                                    <th class="p-md-2 p-0 text-center">8</th>
                                    <th class="p-md-2 p-0 text-center">9</th>
                                    <th class="p-md-2 p-0 text-center">10</th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr>
                                      <td class="p-md-2 p-0 text-center" data-value="0"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="1"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="2"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="3"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="4"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="5"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="6"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="7"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="8"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="9"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="10"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="row mt-4">
                        <div class="col-xl-5 col-lg-6 col-md-12"><h6 class="absoluteToBottom p-md-static mb-lg-5 mb-0 question"><strong class="color-deep-blue">3)</strong> Ha mostrado dominio de los contenidos.</h6></div>
                        <div class="col-xl-7 col-lg-6 col-md-12 px-0">
                            <table class="table table-bordered exclude mt-lg-0 mt-4">
                                <thead>
                                <tr>
                                    <th class="p-md-2 p-0 text-center">0</th>
                                    <th class="p-md-2 p-0 text-center">1</th>
                                    <th class="p-md-2 p-0 text-center">2</th>
                                    <th class="p-md-2 p-0 text-center">3</th>
                                    <th class="p-md-2 p-0 text-center">4</th>
                                    <th class="p-md-2 p-0 text-center">5</th>
                                    <th class="p-md-2 p-0 text-center">6</th>
                                    <th class="p-md-2 p-0 text-center">7</th>
                                    <th class="p-md-2 p-0 text-center">8</th>
                                    <th class="p-md-2 p-0 text-center">9</th>
                                    <th class="p-md-2 p-0 text-center">10</th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr>
                                      <td class="p-md-2 p-0 text-center" data-value="0"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="1"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="2"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="3"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="4"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="5"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="6"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="7"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="8"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="9"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="10"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <div class="container-fluid section mt-6">
                    <div class="row">
                        <div class="col-12"><h5 class="color-deep-blue font-weight-bold"><u>METODOLOGÍA Y MEDIOS DIDÁCTICOS</u></h5></div>
                    </div>
                    <div class="row mt-4">
                        <div class="col-xl-5 col-lg-6 col-md-12"><h6 class="absoluteToBottom p-md-static mb-lg-5 mb-0 question"><strong class="color-deep-blue">1)</strong> La documentación y materiales disponibles (guías, manuales, fichas...) son claros, comprensibles y adecuados.</h6></div>
                        <div class="col-xl-7 col-lg-6 col-md-12 px-0">
                            <table class="table table-bordered exclude mt-lg-0 mt-4">
                                <thead>
                                <tr>
                                    <th class="p-md-2 p-0 text-center">0</th>
                                    <th class="p-md-2 p-0 text-center">1</th>
                                    <th class="p-md-2 p-0 text-center">2</th>
                                    <th class="p-md-2 p-0 text-center">3</th>
                                    <th class="p-md-2 p-0 text-center">4</th>
                                    <th class="p-md-2 p-0 text-center">5</th>
                                    <th class="p-md-2 p-0 text-center">6</th>
                                    <th class="p-md-2 p-0 text-center">7</th>
                                    <th class="p-md-2 p-0 text-center">8</th>
                                    <th class="p-md-2 p-0 text-center">9</th>
                                    <th class="p-md-2 p-0 text-center">10</th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr>
                                      <td class="p-md-2 p-0 text-center" data-value="0"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="1"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="2"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="3"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="4"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="5"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="6"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="7"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="8"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="9"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="10"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="row mt-4">
                        <div class="col-xl-5 col-lg-6 col-md-12"><h6 class="absoluteToBottom p-md-static mb-lg-5 mb-0 question"><strong class="color-deep-blue">2)</strong> En caso de que se hayan utilizado medios audiovisuales (vídeo, DVD, pizarra digital, ordenadores, etc.), éstos han servido para reforzar el aprendizaje.</h6></div>
                        <div class="col-xl-7 col-lg-6 col-md-12 px-0">
                            <table class="table table-bordered exclude mt-lg-0 mt-4">
                                <thead>
                                <tr>
                                    <th class="p-md-2 p-0 text-center">0</th>
                                    <th class="p-md-2 p-0 text-center">1</th>
                                    <th class="p-md-2 p-0 text-center">2</th>
                                    <th class="p-md-2 p-0 text-center">3</th>
                                    <th class="p-md-2 p-0 text-center">4</th>
                                    <th class="p-md-2 p-0 text-center">5</th>
                                    <th class="p-md-2 p-0 text-center">6</th>
                                    <th class="p-md-2 p-0 text-center">7</th>
                                    <th class="p-md-2 p-0 text-center">8</th>
                                    <th class="p-md-2 p-0 text-center">9</th>
                                    <th class="p-md-2 p-0 text-center">10</th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr>
                                      <td class="p-md-2 p-0 text-center" data-value="0"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="1"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="2"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="3"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="4"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="5"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="6"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="7"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="8"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="9"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="10"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="row mt-4">
                        <div class="col-xl-5 col-lg-6 col-md-12"><h6 class="absoluteToBottom p-md-static mb-lg-5 mb-0 question"><strong class="color-deep-blue">3)</strong> En caso de que se hayan utilizado TIC - Tecnologías de la Información y Comunicación (internet, teleconferencia...), éstas han servido para facilitar el aprendizaje.</h6></div>
                        <div class="col-xl-7 col-lg-6 col-md-12 px-0">
                            <table class="table table-bordered exclude mt-lg-0 mt-4">
                                <thead>
                                <tr>
                                    <th class="p-md-2 p-0 text-center">0</th>
                                    <th class="p-md-2 p-0 text-center">1</th>
                                    <th class="p-md-2 p-0 text-center">2</th>
                                    <th class="p-md-2 p-0 text-center">3</th>
                                    <th class="p-md-2 p-0 text-center">4</th>
                                    <th class="p-md-2 p-0 text-center">5</th>
                                    <th class="p-md-2 p-0 text-center">6</th>
                                    <th class="p-md-2 p-0 text-center">7</th>
                                    <th class="p-md-2 p-0 text-center">8</th>
                                    <th class="p-md-2 p-0 text-center">9</th>
                                    <th class="p-md-2 p-0 text-center">10</th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr>
                                      <td class="p-md-2 p-0 text-center" data-value="0"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="1"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="2"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="3"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="4"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="5"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="6"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="7"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="8"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="9"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="10"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="container-fluid section mt-6">
                    <div class="row">
                        <div class="col-12"><h5 class="color-deep-blue font-weight-bold"><u>MEDIOS TÉCNICOS E INSTALACIONES</u></h5></div>
                    </div>
                    <div class="row mt-4">
                        <div class="col-xl-5 col-lg-6 col-md-12"><h6 class="absoluteToBottom p-md-static mb-lg-5 mb-0 question"><strong class="color-deep-blue">1)</strong> Los medios técnicos (pizarras, pantallas, proyectores, TV, vídeo, ordenadores, programas...) han sido suficientes para desarrollar el contenido del curso/ acción formativa.</h6></div>
                        <div class="col-xl-7 col-lg-6 col-md-12 px-0">
                            <table class="table table-bordered exclude mt-lg-0 mt-4">
                                <thead>
                                <tr>
                                    <th class="p-md-2 p-0 text-center">0</th>
                                    <th class="p-md-2 p-0 text-center">1</th>
                                    <th class="p-md-2 p-0 text-center">2</th>
                                    <th class="p-md-2 p-0 text-center">3</th>
                                    <th class="p-md-2 p-0 text-center">4</th>
                                    <th class="p-md-2 p-0 text-center">5</th>
                                    <th class="p-md-2 p-0 text-center">6</th>
                                    <th class="p-md-2 p-0 text-center">7</th>
                                    <th class="p-md-2 p-0 text-center">8</th>
                                    <th class="p-md-2 p-0 text-center">9</th>
                                    <th class="p-md-2 p-0 text-center">10</th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr>
                                      <td class="p-md-2 p-0 text-center" data-value="0"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="1"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="2"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="3"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="4"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="5"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="6"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="7"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="8"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="9"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="10"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="row mt-4">
                        <div class="col-xl-5 col-lg-6 col-md-12"><h6 class="absoluteToBottom p-md-static mb-lg-5 mb-0 question"><strong class="color-deep-blue">2)</strong> Los medios técnicos han funcionado correctamente durante el curso/ acción formativa.</h6></div>
                        <div class="col-xl-7 col-lg-6 col-md-12 px-0">
                            <table class="table table-bordered exclude mt-lg-0 mt-4">
                                <thead>
                                <tr>
                                    <th class="p-md-2 p-0 text-center">0</th>
                                    <th class="p-md-2 p-0 text-center">1</th>
                                    <th class="p-md-2 p-0 text-center">2</th>
                                    <th class="p-md-2 p-0 text-center">3</th>
                                    <th class="p-md-2 p-0 text-center">4</th>
                                    <th class="p-md-2 p-0 text-center">5</th>
                                    <th class="p-md-2 p-0 text-center">6</th>
                                    <th class="p-md-2 p-0 text-center">7</th>
                                    <th class="p-md-2 p-0 text-center">8</th>
                                    <th class="p-md-2 p-0 text-center">9</th>
                                    <th class="p-md-2 p-0 text-center">10</th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr>
                                      <td class="p-md-2 p-0 text-center" data-value="0"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="1"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="2"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="3"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="4"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="5"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="6"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="7"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="8"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="9"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="10"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="row mt-4">
                        <div class="col-xl-5 col-lg-6 col-md-12"><h6 class="absoluteToBottom p-md-static mb-lg-5 mb-0 question"><strong class="color-deep-blue">3)</strong> El aula y las instalaciones (espacio, mobiliario, niveles de luminosidad, acústica, ventilación y climatización...) han sido apropiadas para el desarrollo del curso/ acción formativa.</h6></div>
                        <div class="col-xl-7 col-lg-6 col-md-12 px-0">
                            <table class="table table-bordered exclude mt-lg-0 mt-4">
                                <thead>
                                <tr>
                                    <th class="p-md-2 p-0 text-center">0</th>
                                    <th class="p-md-2 p-0 text-center">1</th>
                                    <th class="p-md-2 p-0 text-center">2</th>
                                    <th class="p-md-2 p-0 text-center">3</th>
                                    <th class="p-md-2 p-0 text-center">4</th>
                                    <th class="p-md-2 p-0 text-center">5</th>
                                    <th class="p-md-2 p-0 text-center">6</th>
                                    <th class="p-md-2 p-0 text-center">7</th>
                                    <th class="p-md-2 p-0 text-center">8</th>
                                    <th class="p-md-2 p-0 text-center">9</th>
                                    <th class="p-md-2 p-0 text-center">10</th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr>
                                      <td class="p-md-2 p-0 text-center" data-value="0"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="1"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="2"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="3"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="4"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="5"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="6"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="7"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="8"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="9"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                      <td class="p-md-2 p-0 text-center" data-value="10"><h4 class="font-weight-bold invisible" aria-hidden="true">&times;</h4></td>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <input type="hidden" id="questionnaireInput" name="questionnaire">
        <button type="submit" class="btn bg-deep-blue text-white border-deep-blue px-4 mt-5 centerHorizontal"><strong>Finalizar</strong></button>
    </form>
</div>



<script type="text/javascript" src="<?php echo e(asset('js/quality.js')); ?>"></script>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/zb3f46kb/projects_data/fuerteventura2000_data/resources/views/fulfillQualityQuestionnaire.blade.php ENDPATH**/ ?>