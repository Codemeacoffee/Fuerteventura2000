<?php $__env->startSection('header'); ?>
<?php $__env->startSection('title'); ?>Contacto - Fuerteventura2000 <?php $__env->stopSection(); ?>
<?php $__env->startSection('description'); ?>Contacta con Fuerteventura2000, tenemos sede en Fuerteventura, Gran Canaria y Tenerife. <?php $__env->stopSection(); ?>
<?php $__env->startSection('img'); ?><?php echo e(asset('images/uploads/'.$contactTexts['img-1'])); ?> <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<!-- G E N E R I C   H E A D -->

<div id="genericHead">
    <img class="w-100 h-75 ed-img" data-ed="img-1" src="<?php echo e(asset('images/uploads/'.$contactTexts['img-1'])); ?>">
    <div class="layer"></div>
</div>

<!-- E N D   G E N E R I C   H E A D -->

<!--  L O C A T I O N   O P T I O N S -->

<div id="genericOptions" class="overlapTop d-md-block d-none">
    <div class="container-fluid">
        <div class="row">
            <div class="col-xl-6 offset-xl-3 col-lg-8 offset-lg-2 col-10 offset-1">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-4">
                            <a href="<?php echo e(url('contact/Fuerteventura')); ?>">
                                <div class="w-100 bg-grey option rounded shadow <?php if($location == 'Fuerteventura') echo 'current' ?>">
                                    <i class="icon-FV d-inline-block color-slate-blue centerHorizontal py-xl-5 py-4"></i>
                                    <h2 class="color-slate-blue text-center px-4 pb-5">Fuerteventura</h2>
                                </div>
                            </a>
                        </div>
                        <div class="col-4">
                            <a href="<?php echo e(url('contact/Gran Canaria')); ?>">
                                <div class="w-100 bg-grey option rounded shadow <?php if($location == 'Gran Canaria') echo 'current' ?>">
                                    <i class="icon-GC d-inline-block color-slate-blue centerHorizontal py-xl-5 py-4"></i>
                                    <h2 class="color-slate-blue text-center px-4 pb-5">Gran Canaria</h2>
                                </div>
                            </a>
                        </div>
                        <div class="col-4">
                            <a href="<?php echo e(url('contact/Tenerife')); ?>">
                                <div class="w-100 bg-grey option rounded shadow <?php if($location == 'Tenerife') echo 'current' ?>">
                                    <i class="icon-TF d-inline-block color-slate-blue centerHorizontal py-xl-5 py-4"></i>
                                    <h2 class="color-slate-blue text-center px-4 pb-5">Tenerife</h2>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- E N D   L O C A T I O N   O P T I O N S -->

<!-- M O B I L E   L O C A T I O N S -->

<div class="container-fluid d-md-none d-block pb-4">
    <div class="row">
        <div class="col-xl-10 offset-xl-1 col-12 offset-0">
            <div class="d-flex mb-4">
                <h1 class="color-slate-blue w-xs-100 text-xs-center noWrap pr-sm-4 pr-0"><strong>Localización</strong></h1>
                <hr class="titleHr w-100 mt-5">
            </div>
            <div class="container-fluid">
                <div class="row">
                    <div class="col-4">
                        <a href="<?php echo e(url('contact/Fuerteventura')); ?>">
                            <div class="w-100">
                                <i class="icon-FV d-inline-block color-slate-blue centerHorizontal pb-2 <?php if($location == 'Fuerteventura') echo 'mobileLocationCurrent' ?>"></i>
                                <h6 class="color-slate-blue text-center <?php if($location == 'Fuerteventura') echo 'mobileLocationCurrent' ?>">Fuerteventura</h6>
                            </div>
                        </a>
                    </div>
                    <div class="col-4">
                        <a href="<?php echo e(url('contact/Gran Canaria')); ?>">
                            <div class="w-100">
                                <i class="icon-GC d-inline-block color-slate-blue centerHorizontal pb-2 <?php if($location == 'Gran Canaria') echo 'mobileLocationCurrent' ?>"></i>
                                <h6 class="color-slate-blue text-center <?php if($location == 'Gran Canaria') echo 'mobileLocationCurrent' ?>">Gran Canaria</h6>
                            </div>
                        </a>
                    </div>
                    <div class="col-4">
                        <a href="<?php echo e(url('contact/Tenerife')); ?>">
                            <div class="w-100">
                                <i class="icon-TF d-inline-block color-slate-blue centerHorizontal pb-2 <?php if($location == 'Tenerife') echo 'mobileLocationCurrent' ?>"></i>
                                <h6 class="color-slate-blue text-center <?php if($location == 'Tenerife') echo 'mobileLocationCurrent' ?>">Tenerife</h6>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- E N D   M O B I L E   L O C A T I O N S -->

<!-- E N D   L O C A T I O N   O P T I O N S -->

<!-- C O N T A C T -->

<div id="contact" class="moveTop mt0-tablet-mobile">
    <div class="container-fluid mb-6">
        <div class="row">
            <div class="col-lg-10 offset-lg-1 col-12 offset-0 ">
                <div class="d-flex mb-2">
                    <h1 class="color-slate-blue noWrap pr-4"><strong class="ed-text-minus" data-ed="title-1"><?php echo $contactTexts['title-1']; ?></strong></h1>
                    <hr class="titleHr w-100 mt-5">
                </div>
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-10 offset-lg-1 col-12 offset-0 px-md-2 px-0">
                            <div class="row">
                                <div class="col-lg-8 col-md-7 col-12 px-ml-5 px-2">
                                    <?php

                                    foreach ($contacts as $contact){
                                        echo '<div class="mb-5">
                                            <h6 class="my-4"><strong>'.$contact['name'].'</strong></h6>
                                            <noscript>
                                            <a target="_blank" href="https://www.google.com/search?q='.$contact['address'].'"><strong>Ver localización en Google</strong></a>
                                            </noscript>
                                            <iframe height="350" class="w-100 noScriptDisplayNone" src="https://maps.google.com/maps?q='.$contact['address'].'&t=&z=13&ie=UTF8&iwloc=&output=embed" frameborder="0"></iframe>
                                            <div class="container-fluid">
                                            <div class="row mt-4">
                                            <div class="col-md-3 col-12">
                                            <div class="d-flex">
                                            <i class="icon-phone mr-2"></i><p><strong>'.$contact['phone'].'</strong></p>
                                            </div>
                                            </div>
                                            <div class="col-md-9 col-12">
                                            <div class="d-flex">
                                            <i class="icon-map mr-2"></i><p><strong>'.$contact['address'].'</strong></p>
                                            </div>
                                            </div>
                                            </div>
                                            </div>
                                            </div>';
                                    }

                                    ?>
                                </div>
                                <div class="col-lg-4 col-md-5 col-12">
                                    <div class="bg-grey rounded shadow stickyBox mt-md-5 mt-0">
                                        <form method="post" action="<?php echo e(url('contactUs/'.$location)); ?>">
                                            <div class="p-md-5 p-4">
                                                <?php echo e(csrf_field()); ?>

                                                <input class="styledInput bg-grey w-100 mb-4" type="text" name="name" placeholder="Nombre" required>
                                                <input class="styledInput bg-grey w-100 mb-4" type="text" name="email" placeholder="Email" required>
                                                <input class="styledInput bg-grey w-100 mb-4" type="number" name="phone" placeholder="Teléfono" required>
                                                <textarea class="styledInput bg-grey w-100" rows="4" name="message" placeholder="Mensaje" required></textarea>
                                                <button class="btn color-deep-blue border-deep-blue centerHorizontal px-4 mt-5"><strong>Enviar</strong></button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- E N D   C O N T A C T -->

<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Fuerteventura2000\resources\views/contact.blade.php ENDPATH**/ ?>