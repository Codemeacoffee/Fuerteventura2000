<?php $__env->startSection('header'); ?>
<?php $__env->startSection('title'); ?>Innobonos - Fuerteventura2000 <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-12 text-center">
            <img src="<?php echo e(asset('images/innobonos-logo.png')); ?>" style="object-fit: cover" class="w-50">
        </div>
    </div>
        
    <div class="row mt-3">
        <div class="col-12">
            
            <p><b>Subvención cofinanciada por el Fondo Europeo de Desarrollo Regional y el Gobierno de Canarias.</b></p>
            
                
            <p>Escuela de Hostelería Europea, S.A. ha recibido una subvención cofinanciada al 85% POR EL FONDO EUROPEO DE DESARROLLO REGIONAL y subvencionada en un 70% por el Gobierno de Canarias dentro de los BONOS PARA LA 
            TRANSFORMACIÓN DIGITAL DE LA EMPRESA CANARIA, EJERCICIO 2020, MOTIVADO POR LA CRISIS SANITARIA DE LA COVID-19.</p><br>
            <p>Los objetivos propuestos y conseguidos con esta subvención han sido:</p><br>
            <p>
                1.       Centralización de tareas administrativas:<br>
                
            <ul class="ml-5">
                <li>a.       Incorporación de herramientas para gestionar las tareas departamentales.</li><br>
                
                <li>b.      Facilitar la toma de decisiones mediante la implantación de un dashboard o panel de indicadores.</li><br>
                
                <li>c.       Herramientas de trazabilidad de los datos y seguimiento de los alumnos.</li><br>
                
                
                <li>d.      Sistemas de acceso a la información en tiempo real.</li><br>
            </ul>
                
                2.       Acceso a la información.<br>
                <ul class="ml-5">
                <li>a.       Centralización de los datos, mejorando su registro y evitando su duplicidad.</li><br>
                
                <li>b.      Control y acceso a los distintos niveles de información mediante un sistema avanzado de permisos.</li><br>
                
                <li>c.       Presentación de informes instantáneo y actualizado.</li><br>
                </ul>
                3.       Posibilidad de compartir información entre todos los componentes de la organización.<br>
                <ul class="ml-5">
                <li>a.       Creación de un medio de comunicación que mejore la interconexión entre departamentos.</li><br>
                
                <li>b.      Tratamiento único de los datos.</li><br>
                
                <li>c.       Implementación de una herramienta que mejorará los procesos de captación de alumnos.</li><br>
                </ul>
                4.       Eliminación de procesos redundantes o innecesarios.<br>
                <ul class="ml-5">
                <li>a.       Control de procesos activos y finalizados.</li><br>
                </ul>
                5.       Mejora de la experiencia educativa del alumno.<br>
                <ul class="ml-5">
                <li>a.       Exposición amigable de los datos, por los que el alumno podrá conocer y consultar sus datos de manera sencilla y accesible.</li><br>
            </ul>
            </p>
            <p>Sitio web de Fondos Europeos del Gobierno de Canarias: <a href="http://www.gobiernodecanarias.org/hacienda/dgplani/fondos_europeos">http://www.gobiernodecanarias.org/hacienda/dgplani/fondos_europeos</a></p><br>
            <p>Sitio web de La Dirección General de Fondos Comunitarios del Ministerio de Hacienda y Administraciones Públicas: 
            <a href="http://www.dgfc.sepg.minhap.gob.es/sitios/dgfc/es-ES/ipr/Paginas/inicio.aspx">http://www.dgfc.sepg.minhap.gob.es/sitios/dgfc/es-ES/ipr/Paginas/inicio.aspx</a></p><br>
        </div>
    </div>
        
</div>
    

<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/zb3f46kb/projects_data/fuerteventura2000_data/resources/views/innobonos.blade.php ENDPATH**/ ?>