<?php

namespace Fuerteventura2000;

use Illuminate\Database\Eloquent\Model;

class Newsletter extends Model
{
    protected $fillable = [
        'email'
    ];
}
