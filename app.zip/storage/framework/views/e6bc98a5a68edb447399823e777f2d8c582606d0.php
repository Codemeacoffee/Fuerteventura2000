<?php $__env->startSection('header'); ?>
<?php $__env->startSection('content'); ?>

<!-- G E N E R I C   H E A D -->

<div id="genericHead" class="mt-6">
    <img class="w-100 h-75 ed-img" data-ed="img-1" src="<?php echo e(asset('images/uploads/'.$companyTexts['img-1'])); ?>">
    <div class="layer"></div>
</div>

<!-- E N D   G E N E R I C   H E A D -->

<div>
    <div class="container-fluid">
        <div class="row">
            <div class="col-8 offset-2">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">
                            <div class="container-fluid bg-slate-blue rounded mb-5">
                                <div class="row p-5">
                                    <div class="col-8">
                                        <img class="w-100 ed-img" data-ed="img-5" alt="Trazado con siluetas en blanco de diferentes personas" src="<?php echo e(asset('images/uploads/'.$companyTexts['img-2'])); ?>">
                                    </div>
                                    <div class="col-4">
                                        <h1 class="text-white mt-4 ed-text-minus" data-ed="title-1">
                                            <?php echo $companyTexts['title-1']; ?>

                                        </h1>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row px-4 my-5">
                        <div class="ed-text w-100" data-ed="text-1"><?php echo $companyTexts['text-1']; ?></div>
                    </div>
                    <div class="row my-5">
                        <div class="col-6 p-5">
                            <img class="w-100 h-100 ed-img" data-ed="img-6" src="<?php echo e(asset('images/uploads/'.$companyTexts['img-3'])); ?>">
                        </div>
                        <div class="col-6 p-5">
                            <div class="m-5">
                                <h4 class="color-slate-blue">
                                    <strong class="ed-text-minus" data-ed="title-2"><?php echo $companyTexts['title-2']; ?></strong>
                                </h4>
                                <br>
                                <div class="ed-text w-100" data-ed="text-2">
                                    <?php echo $companyTexts['text-2']; ?>

                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row px-4 my-5">
                        <div class="ed-text w-100" data-ed="text-3"><?php echo $companyTexts['text-3']; ?></div>
                    </div>
                    <div class="row my-5">
                        <div class="col-6 p-5">
                            <div class="m-5">
                                <h4 class="color-slate-blue">
                                    <strong class="ed-text-minus" data-ed="title-3"><?php echo $companyTexts['title-3']; ?></strong>
                                </h4>
                                <br>
                                <div class="ed-text" data-ed="text-4">
                                    <?php echo $companyTexts['text-4']; ?>

                                </div>
                            </div>
                        </div>
                        <div class="col-6 p-5">
                            <img class="w-100 h-100 ed-img" data-ed="img-7" src="<?php echo e(asset('images/uploads/'.$companyTexts['img-4'])); ?>">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Fuerteventura2000\resources\views/company.blade.php ENDPATH**/ ?>