<?php $__env->startSection('header'); ?>
<?php $__env->startSection('title'); ?>Administración - Panel de Control <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="modal fade" id="userCreator" tabindex="-1" role="dialog" aria-labelledby="Modal for user creation" aria-hidden="true">
    <div class="modal-dialog modal-xl" role="document">
        <div class="modal-content">
            <form method="post" action="<?php echo e(url('generateQualityQuestionnaireUsers')); ?>">
                <?php echo e(csrf_field()); ?>


                <div class="modal-header border-0">
                    <h5 class="modal-title w-100 text-center color-black">Crear usuarios</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body qualityQuestionnaireCreateUsers px-5">
                    <div class="col-11 offset-1 pb-2">
                        <div class="container-fluid">
                            <div class="row">
                                <div class="col-3">
                                    <h5 class="color-deep-blue">Nombre</h5>
                                </div>
                                <div class="col-3">
                                    <h5 class="color-deep-blue">Asistencia</h5>
                                </div>
                                <div class="col-3">
                                    <h5 class="color-deep-blue">Localización</h5>
                                </div>
                                <div class="col-3">
                                    <h5 class="color-deep-blue">Destinatario</h5>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php
                    if(Count($courses) < 1) echo '<p class="text-center mt-4"><strong>Se han generado usuarios y contraseñas para todos los cursos existentes.</strong></p>';
                    foreach($courses as $course){
                        echo'
                         <div class="col-12">
                            <div class ="row border-deep-blue border-top border-bottom py-2">
                                <div class="col-1">
                                <span class="d-table h-100"><p class="d-table-cell align-middle"><input class="input-big" type="checkbox" name="course-'.$course['id'].'" id="course-'.$course['id'].'"></p></span>
                                </div>
                                <div class="col-11">
                                    <label class="d-block" for="course-'.$course['id'].'">
                                        <div class="container-fluid h-100">
                                            <div class="row pointer-events-none h-100">
                                                <div class="col-3">
                                                    <span class="d-table h-100"><p class="d-table-cell align-middle">'.$course['title'].'</p></span>
                                                </div>
                                                <div class="col-3">
                                                    <span class="d-table h-100"><p class="d-table-cell align-middle">'.$course['onSite'].'</p></span>
                                                </div>
                                                <div class="col-3">
                                                    <span class="d-table h-100"><p class="d-table-cell align-middle">'.$course['location'].'</p></span>
                                                </div>
                                                <div class="col-3">
                                                    <span class="d-table h-100"><p class="d-table-cell align-middle">'.$course['receiver'].'</p></span>
                                                </div>
                                            </div>
                                        </div>
                                    </label>
                                </div>
                            </div>
                         </div>';
                    }
                    ?>
                </div>
                <div class="modal-footer border-0">
                    <button type="button" class="btn cpBtn bg-deep-blue text-white border-deep-blue px-4" id="select-all"><strong>Seleccionar todos</strong></button>
                    <button type="button" class="btn cpBtn color-deep-blue border-deep-blue px-4" data-dismiss="modal"><strong>Cancelar</strong></button>
                    <button type="submit" class="btn cpBtn bg-deep-blue text-white border-deep-blue px-4"><strong>Crear</strong></button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="container-fluid controlPanel mt-6 pt-5">
    <div class="row h-100">
        <div class="col-12 overflow-auto">
            <div class="col-12">
                <button class="btn bg-deep-blue rounded text-white centerHorizontal px-4 pb-2" data-toggle="modal" data-target="#userCreator"><strong>Crear usuarios</strong></button>
            </div>
            <div class="mt-5 mx-3">
                <div class="row">
                    <div class="col-lg-3 offset-lg-9 col-md-6 offset-md-6 col-12 offset-0">
                        <input id="search" class="form-control" type="text" placeholder="Buscar..">
                    </div>
                </div>
            </div>
            <form method="post" action="<?php echo e(url('editQualityQuestionnaireUsers')); ?>">
                <?php echo e(csrf_field()); ?>

                    <div class="container-fluid mt-4">
                        <div class="row courseBoxes">
                <?php
                    foreach ($qualityQuestionnaireUsers as $qualityQuestionnaireUser){
                        echo '
                            <div class="'.$qualityQuestionnaireUser['course'].' col-md-6 col-12 mb-4">
                                <div class="bg-deep-blue rounded">
                                    <input type="checkbox" class="viewCourseUser" id="'.$qualityQuestionnaireUser['course'].'">
                                    <div class="row px-4 py-2">
                                        <div class="col-xl-11 col-10">
                                            <label class="text-white courseNameIdentifier w-100 m-1 font-weight-bold interactive" for="'.$qualityQuestionnaireUser['course'].'">'.$qualityQuestionnaireUser['course'].'</label>
                                        </div>
                                        <div class="col-xl-1 col-2">
                                            <a href="'.url('controlPanel/qualityQuestionnaireResults/'.$qualityQuestionnaireUser['courseId']).'"><i title="Ver estadísticas" class="glyphicon glyphicon-stats iconBig hover-grey text-white mt-2"></i></a>
                                        </div>
                                    </div>
                                    <div class="userContent col-12 py-lg-3 px-lg-5" id="'.$qualityQuestionnaireUser['id'].'">
                                        <div class="row pb-4">
                                            <div class="col-md-6 col-12">
                                                <label for="userName-'.$qualityQuestionnaireUser['courseId'].'"><h6 class="text-white" title="Este campo es obligatorio"><strong>Nombre de usuario</strong><span class="text-danger">*</span></h6></label>
                                                <input type="text" name="userName-'.$qualityQuestionnaireUser['courseId'].'" class="form-control mb-2" id="userName-'.$qualityQuestionnaireUser['courseId'].'" value="'.$qualityQuestionnaireUser['userName'].'" required>
                                            </div>
                                            <div class="col-md-6 col-12">
                                                <label for="pass-'.$qualityQuestionnaireUser['courseId'].'"><h6 class="text-white" title="Este campo es obligatorio"><strong>Contraseña</strong><span class="text-danger">*</span></h6></label>
                                                <input type="text" name="pass-'.$qualityQuestionnaireUser['courseId'].'" class="form-control mb-2" id="pass-'.$qualityQuestionnaireUser['courseId'].'" value="'.decrypt($qualityQuestionnaireUser['password']).'" required>
                                            </div>
                                            <div class="col-md-6 col-12">
                                                <label for="initDate-'.$qualityQuestionnaireUser['courseId'].'"><h6 class="text-white" title="Este campo es opcional"><strong>Fecha de inicio</strong></h6></label>
                                                <input type="text" name="initDate-'.$qualityQuestionnaireUser['courseId'].'" class="form-control datePicker mb-2" id="initDate-'.$qualityQuestionnaireUser['courseId'].'" value="'.$qualityQuestionnaireUser['init_date'].'" autocomplete="off">
                                            </div>
                                            <div class="col-md-6 col-12">
                                                <label for="endDate-'.$qualityQuestionnaireUser['courseId'].'"><h6 class="text-white" title="Este campo es opcional"><strong>Fecha de finalización</strong></h6></label>
                                                <input type="text" name="endDate-'.$qualityQuestionnaireUser['courseId'].'" class="form-control datePicker mb-2" id="endDate-'.$qualityQuestionnaireUser['courseId'].'" value="'.$qualityQuestionnaireUser['end_date'].'" autocomplete="off">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>';
                    }
                    ?>
                    </div>
                </div>
                <div class="modal-footer px-5">
                    <a href="<?php echo e(url('controlPanel')); ?>"><button type="button" class="btn cpBtn color-deep-blue border-deep-blue px-4"><strong>Volver</strong></button></a>
                    <button type="submit" class="btn cpBtn bg-deep-blue text-white border-deep-blue px-4"><strong>Guardar</strong></button>
                </div>
            </form>
        </div>
    </div>
</div>
<script type="text/javascript" src="<?php echo e(url('js/statisticCharts.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(url('js/generateQualityQuestionnaireCharts.js')); ?>"></script>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>

<?php echo $__env->make('adminLayoutMin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/zb3f46kb/projects_data/fuerteventura2000_data/resources/views/administration.blade.php ENDPATH**/ ?>