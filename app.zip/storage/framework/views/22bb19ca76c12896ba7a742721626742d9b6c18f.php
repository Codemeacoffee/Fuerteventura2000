<?php $__env->startSection('header'); ?>
<?php $__env->startSection('title'); ?>Resultados de la encuesta de calidad del curso <?php echo e($course['title']); ?> - Panel de Control <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid mt-6">
    <div class="row pt-5">
        <div class="col-xl-10 offset-xl-1 col-12 offset-0 px-xl-0 px-lg-5">
            <div class="d-flex mb-5">
                <h1 class="color-slate-blue noWrap pr-4"><strong>Resultados de encuesta</strong></h1>
                <hr class="titleHr w-100 mt-5">
            </div>
            <div class="row mb-lg-5 mb-4">
                <div class="col-lg-4 col-md-6 col-12">
                    <p><strong class="color-deep-blue">Curso: </strong><?php echo e($course['title']); ?></p>
                </div>
                <div class="col-lg-4 col-md-6 col-12">
                    <p><strong class="color-deep-blue">Localización: </strong><?php echo e($course['location']); ?></p>
                </div>
                <div class="col-lg-4 col-md-6 col-12">
                    <p><strong class="color-deep-blue">Destinatario: </strong><?php echo e($course['receiver']); ?></p>
                </div>
                <div class="col-lg-4 col-md-6 col-12">
                    <p><strong class="color-deep-blue">Presencial: </strong><?php echo e($course['onSite']); ?></p>
                </div>
                <div class="col-lg-4 col-md-6 col-12">
                    <p><strong class="color-deep-blue">Fecha: </strong><?php echo e(date('d-m-Y', strtotime($course['created_at']))); ?></p>
                </div>
                <div class="col-lg-4 col-md-6 col-12">
                    <p><strong class="color-deep-blue">Total de Participantes: </strong><?php echo e(Count($results)); ?></p>
                </div>
                <div class="col-12">
                    <p><strong class="color-deep-blue">Enlace de descarga: </strong><a class="" href="<?php echo e(url('resultsToMSWord/'.$course['id'])); ?>" target="_blank"><?php echo e(url('resultsToMSWord/'.$course['id'])); ?></a></p>
                </div>
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-4 col-md-6 col-12 mt-lg-5 mt-3">
                            <select class="qualityGraphsSelect form-control">
                                <option value="courseRating" selected="selected">Valoración general del curso</option>
                                <option value="age">Edad / Género</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12 courseRating mb-4">
                    <p><strong>Los votos de los usuarios se catalogan de 0 a 10 (siendo 0 muy en desacuerdo y siendo 10 muy de acuerdo).</strong></p>
                </div>
                <div class="container-fluid">
                    <div class="row">
                    <?php

                    $ages = [];
                    $genders = [['Masculino', 0], ['Femenino', 0]];
                    $votes = [];

                    if(Count($results) > 0){
                        foreach (json_decode(htmlspecialchars_decode($results[0]['content'])) as $result){
                            $questionsBlock = [$result[0], []];
                            echo '<div class="col-12 courseRating mb-5">
                                <h4 class="color-deep-blue">'.$result[0].'</h4>
                                </div>';
                            foreach ($result[1] as $questionAndAnswer){
                                array_push($questionsBlock[1], [$questionAndAnswer[0], [['Usuarios que han votado 0', 0], ['Usuarios que han votado 1', 0], ['Usuarios que han votado 2', 0],
                                    ['Usuarios que han votado 3', 0], ['Usuarios que han votado 4', 0], ['Usuarios que han votado 5', 0], ['Usuarios que han votado 6', 0], ['Usuarios que han votado 7', 0],
                                    ['Usuarios que han votado 8', 0], ['Usuarios que han votado 9', 0], ['Usuarios que han votado 10', 0]]]);
                                echo '<div class="col-md-6 col-12 courseRating">
                                  <p><strong>'.$questionAndAnswer[0].'</strong></p>
                                  <div class="votesCharts"></div>
                                  </div>';
                            }
                            array_push($votes, $questionsBlock);
                        }

                        foreach($results->toArray() as $result){
                            $inArray = false;
                            for ($i = 0; $i < Count($ages); $i++){
                                if($ages[$i][0] == $result['age']){
                                    $ages[$i][1]++;
                                    $inArray = true;
                                    break;
                                }
                            }
                            if(!$inArray) array_push($ages, [$result['age']." años", 1]);

                            for ($i = 0; $i < Count($genders); $i++){
                                if($genders[$i][0] == $result['gender']) $genders[$i][1]++;
                            }

                            $decodedContents = json_decode(htmlspecialchars_decode($result['content']));

                            foreach ($decodedContents as $decodedContent){
                                for($i = 0; $i < Count($votes); $i++){
                                    if($votes[$i][0] == $decodedContent[0]){
                                        for($j = 0; $j < Count($votes[$i][1]); $j++){
                                            if($votes[$i][1][$j][0] == $decodedContent[1][$j][0]){
                                                $votes[$i][1][$j][1][$decodedContent[1][$j][1]][1]++;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    ?>
                        <div class="container-fluid d-none age">
                            <div class="row">
                                <div class="col-12 mb-4">
                                    <p class="age"><strong>Estas son las gráficas de edad y género.</strong></p>
                                </div>
                                <div class="col-md-6 col-12">
                                    <div class="agesChart"></div>
                                </div>
                                <div class="col-md-6 col-12">
                                    <div class="gendersChart"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript" src="<?php echo e(url('js/statisticCharts.js')); ?>"></script>
<script id="chartsScript" type="text/javascript">
    $(window).on('load', function() {
        let courseRating = $('.courseRating');
        let age = $('.age');
        let gendersChart = $('.gendersChart');
        let agesChart = $('.agesChart');
        let votesChars = $('.votesCharts');
        let options = {width: '100%', height: 350, is3D: true};

        google.charts.load('current', {'packages':['corechart']});
        google.charts.setOnLoadCallback(drawCharts);

        function drawCharts() {
            let genderChart = new google.visualization.PieChart(gendersChart[0]);
            let genderChartData = new google.visualization.DataTable();
            let ageChart = new google.visualization.PieChart(agesChart[0]);
            let ageChartData = new google.visualization.DataTable();

            genderChartData.addColumn('string', 'Gender');
            genderChartData.addColumn('number', 'AmountOfEachGender');
            genderChartData.addRows(<?php echo json_encode($genders) ?>);

            ageChartData.addColumn('string', 'Age');
            ageChartData.addColumn('number', 'AmountOfEachAge');
            ageChartData.addRows(<?php echo json_encode($ages) ?>);

            <?php
            $index = 0;

            foreach ($votes as $sections){
                foreach ($sections[1] as $questionsAndAnswers){
                    echo "let voteChart".$index." = new google.visualization.PieChart($($('.votesCharts')[".$index."])[0]);
                            let voteChartData".$index." = new google.visualization.DataTable();

                            voteChartData".$index.".addColumn('string', 'VoteValue');
                            voteChartData".$index.".addColumn('number', 'AmountOfVotes');
                            voteChartData".$index.".addRows(".json_encode($questionsAndAnswers[1]).");

                            voteChart".$index.".draw(voteChartData".$index.", options);";
                    $index++;
                }
            }

            if(Count($results) > 0) echo 'genderChart.draw(genderChartData, options); ageChart.draw(ageChartData, options);';

            ?>
        }
        $(this).on('resize', drawCharts);


        $('.qualityGraphsSelect').on('change', function() {
            if($(this).val() == 'courseRating'){
                courseRating.removeClass('d-none');
                age.addClass('d-none');
            } else {
                age.removeClass('d-none');
                courseRating.addClass('d-none');
            }
            drawCharts();
        });
    });

    $('#chartsScript').remove();
</script>
<script>

</script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>

<?php echo $__env->make('adminLayoutMin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/zb3f46kb/projects_data/fuerteventura2000_data/resources/views/qualityQuestionnaireResults.blade.php ENDPATH**/ ?>