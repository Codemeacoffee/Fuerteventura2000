<div class="row">
    <div class="col-xl-8 offset-xl-2 col-lg-10 offset-lg-1 col-12 offset-0">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-4 col-12 mb-4">
                    <a class="h-100 ed-anchor" data-ed="<?php echo e(url('controlPanel/normative')); ?>"  href="<?php echo e(url('normative')); ?>">
                        <div class="w-100 h-100 bg-grey rounded shadow centerHorizontal pb-4">
                            <img class="w-50 centerHorizontal py-xl-5 py-4" src="<?php echo e(asset('images/icon-doublePaper.png')); ?>">
                            <h2 class="color-slate-blue text-center mx-4">Normativas</h2>
                        </div>
                    </a>
                </div>
                <div class="col-lg-4 col-12 mb-4">
                    <a class="h-100 ed-anchor" data-ed="<?php echo e(url('controlPanel/financialEconomics')); ?>"  href="<?php echo e(url('financialEconomics')); ?>">
                        <div class="w-100 h-100 bg-grey rounded shadow centerHorizontal pb-4">
                            <img class="w-50 centerHorizontal py-xl-5 py-4" src="<?php echo e(asset('images/icon-paper.png')); ?>">
                            <h2 class="color-slate-blue text-center mx-4">Económico <br> Financiera</h2>
                        </div>
                    </a>
                </div>
                <div class="col-lg-4 col-12 mb-4">
                    <a class="h-100 ed-anchor" data-ed="<?php echo e(url('controlPanel/grantsAndSubsidies')); ?>" href="<?php echo e(url('grantsAndSubsidies')); ?>">
                        <div class="w-100 h-100 bg-grey rounded shadow pb-4">
                            <img class="w-50 centerHorizontal py-xl-5 py-4" src="<?php echo e(asset('images/icon-coinOverHand.png')); ?>">
                            <h2 class="color-slate-blue text-center mx-4">Ayudas y <br> Subvenciones</h2>
                        </div>
                    </a>
                </div>
            </div>
            <div class="row ">
                <div class="col-lg-4 col-12 mb-4">
                    <a class="h-100 ed-anchor" data-ed="<?php echo e(url('controlPanel/institutions')); ?>"  href="<?php echo e(url('institutions')); ?>">
                        <div class="w-100 h-100 bg-grey rounded shadow centerHorizontal pb-4">
                            <img class="w-50 centerHorizontal py-xl-5 py-4" src="<?php echo e(asset('images/icon-parthenon.png')); ?>">
                            <h2 class="color-slate-blue text-center mx-4">Institucional</h2>
                        </div>
                    </a>
                </div>
                <div class="col-lg-4 col-12 mb-4">
                    <a class="h-100 ed-anchor" data-ed="<?php echo e(url('controlPanel/contracts')); ?>"  href="<?php echo e(url('contracts')); ?>">
                        <div class="w-100 h-100 bg-grey rounded shadow centerHorizontal pb-4">
                            <img class="w-50 centerHorizontal py-xl-5 py-4" src="<?php echo e(asset('images/icon-paperPen.png')); ?>">
                            <h2 class="color-slate-blue text-center mx-4">Contratos</h2>
                        </div>
                    </a>
                </div>
                <div class="col-lg-4 col-12 mb-4">
                    <a class="h-100 ed-anchor" data-ed="<?php echo e(url('controlPanel/transparencyCommissioner')); ?>" href="<?php echo e(url('transparencyCommissioner')); ?>">
                        <div class="w-100 h-100 bg-grey rounded shadow pb-4">
                            <img class="w-50 centerHorizontal py-xl-5 py-4" src="<?php echo e(asset('images/icon-TwoPersons.png')); ?>">
                            <h2 class="color-slate-blue text-center mx-4">Comisionado <br> de Transparencia</h2>
                        </div>
                    </a>
                </div>
            </div>
            <div class="row mb-5">
                <div class="col-lg-4 col-12 mb-4">
                    <a class="h-100 ed-anchor" data-ed="<?php echo e(url('controlPanel/organization')); ?>"  href="<?php echo e(url('organization')); ?>">
                        <div class="w-100 h-100 bg-grey rounded shadow centerHorizontal pb-4">
                            <img class="w-50 centerHorizontal py-xl-5 py-4" src="<?php echo e(asset('images/icon-organizationChart.png')); ?>">
                            <h2 class="color-slate-blue text-center mx-4">Organizativa</h2>
                        </div>
                    </a>
                </div>
                <div class="col-lg-4 col-12 mb-4">
                    <a class="h-100 ed-anchor" data-ed="<?php echo e(url('controlPanel/covenants')); ?>"  href="<?php echo e(url('covenants')); ?>">
                        <div class="w-100 h-100 bg-grey rounded shadow centerHorizontal pb-4">
                            <img class="w-50 centerHorizontal py-xl-5 py-4" src="<?php echo e(asset('images/icon-handshake.png')); ?>">
                            <h2 class="color-slate-blue text-center mx-4">Convenios</h2>
                        </div>
                    </a>
                </div>
                <div class="col-lg-4 col-12 mb-4">
                    <a class="h-100 ed-anchor" data-ed="<?php echo e(url('controlPanel/accessToInformation')); ?>" href="<?php echo e(url('accessToInformation')); ?>">
                        <div class="w-100 h-100 bg-grey rounded shadow pb-4">
                            <img class="w-50 centerHorizontal py-xl-5 py-4" src="<?php echo e(asset('images/icon-info.png')); ?>">
                            <h2 class="color-slate-blue text-center mx-4">Acceso a la <br> Información</h2>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /home/zb3f46kb/projects_data/fuerteventura2000_data/resources/views/transparencyPortalLinks.blade.php ENDPATH**/ ?>