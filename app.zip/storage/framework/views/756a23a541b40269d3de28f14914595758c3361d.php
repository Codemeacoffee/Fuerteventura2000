<?php $__env->startSection('header'); ?>
    <!DOCTYPE html>
<html itemscope lang="es" dir="ltr" itemtype="https://schema.org/WebSite">
<head>
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <meta name="author" content="Inversiones Borma S.L.">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta charset="utf-8">
    <!-- SEO -->
    <meta name="description" content="Administrador de Fuerteventura2000">
    <meta property="og:site_name" content="Fuerteventura2000">
    <meta property="og:title" content="<?php echo $__env->yieldContent('title'); ?>">
    <meta property="og:url" content="<?php echo e(url()->full()); ?>">
    <meta property="og:description" content="Administrador de Fuerteventura2000">
    <meta property="og:image" itemprop="image" content="<?php echo e(asset('images/ftv2000SEO.jpg')); ?>">
    <meta property="og:type" content="website" />
    <meta property="og:locale" content="es_ES" />
    <meta property="og:updated_time" content="<?php echo e(strtotime(date('Y-m-d'))); ?>"/>
    <!-- SEO -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/glyphicon.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/main.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/controlPanel.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/courses.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/contact.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/bootstrapAdaptation.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/effects.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/utils.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('js/jquery-ui-1.12.1/jquery-ui.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/quilljsSnow.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/fileinput.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/explorer.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/responsive.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('fonts/style.css')); ?>">
    <link rel="shortcut icon" type="image/png" href= "<?php echo e(asset('images/ftv2000favicon.png')); ?>"/>
    <link rel="preload" href="<?php echo e(asset('images/loading.svg')); ?>" as="image">
    <script type="text/javascript" src="<?php echo e(asset('js/jquery-3.3.1.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/jquery-ui-1.12.1/jquery-ui.min.js')); ?>" defer></script>
    <script type="text/javascript" src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/piexif.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/fileinput.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/explorer.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/quilljs.min.js')); ?>" defer></script>
    <script type="text/javascript" src="<?php echo e(asset('js/cookies.min.js')); ?>" defer></script>
    <script type="text/javascript" src="<?php echo e(asset('js/utils.js')); ?>" defer></script>
</head>
<body>

<!-- N O   S C R I P T -->

<noscript>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/scriptsDisabled.css')); ?>">
    <div class="container-fluid">
        <div class="col-xl-6 col-lg-8 col-md-10 col-12 absoluteCenterBoth bg-deep-blue rounded shadow py-5 px-xl-5 px-lg-5 px-md-5 px-3">
            <img alt="Logo de la Editorial Paralelo28" class="centerHorizontal" src="<?php echo e(asset('images/ftv2000logo.svg')); ?>">
            <h5 class="mt-4 text-white">El administrador de  Fuerteventura2000.com necesita Javascript para poder operar correctamente, por ello, le pedimos que active
                Javascript para poder continuar. <br><br> Esto lo puede hacer desde los siguientes enlaces segun su navegador:
            </h5>
            <div class="row mt-4">
                <div class="col-xl-3 col-lg-3 col-6">
                    <ul class="list-group">
                        <li class="list-group-item bg-deep-blue border-0"><a href="https://www.whatismybrowser.com/guides/how-to-enable-javascript/chrome" target="_blank"><strong class="text-white">Chrome</strong></a></li>
                        <li class="list-group-item bg-deep-blue border-0"><a href="https://www.whatismybrowser.com/guides/how-to-enable-javascript/safari-iphone" target="_blank"><strong class="text-white">Safari (iphone)</strong></a></li>
                    </ul>
                </div>
                <div class="col-xl-3 col-lg-3 col-6">
                    <ul class="list-group">
                        <li class="list-group-item bg-deep-blue border-0"><a href="https://www.whatismybrowser.com/guides/how-to-enable-javascript/firefox" target="_blank"><strong class="text-white">Firefox</strong></a></li>
                        <li class="list-group-item bg-deep-blue border-0"><a href="https://www.whatismybrowser.com/guides/how-to-enable-javascript/safari-ipad" target="_blank"><strong class="text-white">Safari (ipad)</strong></a></li>
                    </ul>
                </div>
                <div class="col-xl-3 col-lg-3 col-6">
                    <ul class="list-group">
                        <li class="list-group-item bg-deep-blue border-0"><a href="https://www.whatismybrowser.com/guides/how-to-enable-javascript/opera" target="_blank"><strong class="text-white">Opera</strong></a></li>
                        <li class="list-group-item bg-deep-blue border-0"><a href="https://www.whatismybrowser.com/guides/how-to-enable-javascript/edge" target="_blank"><strong class="text-white">Edge</strong></a></li>
                    </ul>
                </div>
                <div class="col-xl-3 col-lg-3 col-6">
                    <ul class="list-group">
                        <li class="list-group-item bg-deep-blue border-0"><a href="https://www.whatismybrowser.com/guides/how-to-enable-javascript/safari" target="_blank"><strong class="text-white">Safari</strong></a></li>
                        <li class="list-group-item bg-deep-blue border-0"><a href="https://www.whatismybrowser.com/guides/how-to-enable-javascript/internet-explorer" target="_blank"><strong class="text-white">Internet Explorer</strong></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</noscript>

<!-- E N D   N O   S C R I P T -->

<!-- L O A D I N G   L A Y E R -->

<div class="loadingLayer">
    <div class="position-relative h-100">
        <img width="25%" height="25%" class="absoluteCenterBoth" alt="Icono de carga" src="<?php echo e(asset('images/loading.svg')); ?>">
    </div>
</div>
<script id="loadingScript" type="text/javascript">
    $(window).on("load", function () {
        $('.loadingLayer').fadeOut("slow");
        $('#loadingScript').remove();
    });
</script>

<!-- E N D   L O A D I N G   L A Y E R  -->


<!-- C O O K I E S   P O P   U P -->

<div id="cookie_directive_container" class="container position-fixed cookies bg-slateGrey-color rounded shadow d-none">
    <nav class="navbar navbar-default navbar-fixed-bottom">

        <div class="container">
            <div class="navbar-inner navbar-content-center" id="cookie_accept">

                <a class="btn btn-default w-100 acceptCookies"><h5 class="theX interactive float-right hoverRed closeUserAccess" data-dismiss="modal" aria-hidden="true">×</h5></a>
                <p class="text-muted credit">
                    Solicitamos su permiso para obtener datos estadísticos de su navegación en esta web, en cumplimiento del Real Decreto-ley 13/2012.
                    Si continúa navegando consideramos que acepta el uso de cookies. <a target="_blank" href="<?php echo e(url('cookiesPolicy')); ?>">Más Información.</a>
                </p>
                <br>
                <button class="btn btn-danger centerHorizontal mb-4 acceptCookies"><strong class="px-4">Aceptar</strong></button>
            </div>
        </div>

    </nav>
</div>

<!-- E N D   C O O K I E S   P O P   U P  -->

<?php if($errors->any()): ?>

    <!-- E R R O R S -->

    <div id="errorModal" class="modal fade">
        <div class="modal-dialog modal-dialog-centered modal" role="document">
            <div class="modal-content overflow-auto">
                <div class="modal-body">
                    <h2 class="text-center ml-4 mb-4">
                        <strong>Error</strong>
                        <span class="theX interactive float-right hoverRed closeUserAccess" data-dismiss="modal" aria-hidden="true">×</span>
                    </h2>
                    <div class="row"><i id="modalSignal" class="glyphicon glyphicon-alert centerHorizontal pb-4"></i></div>
                    <div class="row"><p class="text-center px-5 pb-2 w-100"><strong><?php echo e($errors->first()); ?></strong></p></div>
                </div>
            </div>
        </div>
    </div>

    <script id="errorScript" type="text/javascript">
        $('#errorModal').modal('toggle');
        $('#errorScript').remove();
    </script>

    <!-- E N D   E R R O R S -->

<?php endif; ?>

<?php if(Session::has('successMessage')): ?>

    <!-- O T H E R   M E S S A G E S   A N D   A L T E R N A T E   B E H A V I O U R S -->

    <div id="messageModal" class="modal fade">
        <div class="modal-dialog modal-lg modal-dialog-centered modal" role="document">
            <div class="modal-content overflow-auto">
                <div class="modal-body pt-1">
                    <h2 class="text-center ml-3 mb-4">
                        <span class="theX interactive float-right hoverRed closeUserAccess dt-2" data-dismiss="modal" aria-hidden="true">×</span>
                    </h2>
                    <div class="row py-5"><i id="modalSignal" class="glyphicon glyphicon-ok centerHorizontal mb-4"></i></div>
                    <div class="row">
                        <p class="text-center px-5 w-100">
                            <strong class="py-2 d-block"><?php echo e(Session::get('successMessage')); ?></strong>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script id="messageScript" type="text/javascript">
        $('#messageModal').modal('toggle');
        $('#messageScript').remove();
    </script>

    <!-- E N D   O T H E R   M E S S A G E S   A N D   A L T E R N A T E   B E H A V I O U R S -->

<?php endif; ?>

<!-- N A V B A R -->

<div id="navbar" class="fixed-top">
    <nav class="navbar navbar-expand-lg navbar-dark bg-slate-blue px-lg-5 px-0">
        <div class="container-fluid px-0">
            <div class="row align-items-center w-100">
                <div class="col-12 mb-lg-0">
                    <div class="row">
                        <div class="col-3">
                            <a class="navbar-brand" href="<?php echo e(url('controlPanel')); ?>">
                                <img src="<?php echo e(asset('images/ftv2000logo.svg')); ?>" width="200" height="50" alt="Logo de Fuerteventura 2000">
                            </a>
                        </div>
                        <div class="col-xl-6 offset-xl-3 col-lg-7 offset-lg-2 d-lg-block d-none">
                            <div class="collapse navbar-collapse float-right w-100" id="navbarSupportedContent">
                                <div class="container-fluid">
                                    <div class="row float-right">
                                        <a target="_blank" class="previewAnchor mt-2 mr-4"><button class="btn bg-grey text-black-50"><strong>Ver Web</strong></button></a>
                                        <a href="<?php echo e(url('closeSession')); ?>" class="mt-2"><button class="btn bg-grey text-black-50"><strong>Cerrar sesión</strong></button></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-2 col-9 d-lg-none d-md-block">
                            <button class="navbar-toggler float-right mt-3" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                                <i class="glyphicon glyphicon-menu-hamburger text-white "></i>
                            </button>
                        </div>
                    </div>
                </div>
                <div class="col-xl-6 offset-xl-4 col-lg-8 offset-lg-2 col-12 pr-lg-2 pr-sm-0">
                    <div class="collapse navbar-collapse float-right w-100 pl-lg-0 pl-4" id="navbarSupportedContent">
                        <nav class="navbar navbar-expand-lg mobileFullView navbar-dark px-0 w-100 d-lg-none d-inline-block mt-3 border-top">
                            <div class="container-fluid px-xl-5 px-lg-0">
                                <div class="row align-items-center w-100">
                                    <div class="col-12 my-2 pr-0">
                                        <div>
                                            <div class="d-sm-flex text-center d-block justify-content-around w-100">
                                                <a class="text-white mobileBigText d-md-inline d-block my-3" href="<?php echo e(url('controlPanel')); ?>"><strong <?php if($page == '') echo 'class="selected"' ?>>Inicio</strong></a>
                                                <div class="showFloatingBox d-flex align-items-center position-relative">
                                                    <strong class="text-white w-100 my-3 mobileBigText <?php if($page == 'aboutUs' || $page == 'certificates' || $page == 'joinUs') echo 'selected' ?>">Conócenos<i class="glyphicon glyphicon-chevron-down ml-1 small"></i></strong>
                                                    <div class="floatingBox centerHorizontal">
                                                        <div class="bg-grey shadow py-2 px-4">
                                                            <a class="text-white mobileBigText d-block noWrap my-3" href="<?php echo e(url('controlPanel/aboutUs')); ?>"><strong class="color-slate-blue <?php if($page == 'aboutUs') echo 'selected' ?>">¿Quiénes somos?</strong></a>
                                                            <a class="text-white mobileBigText d-block noWrap my-3" href="<?php echo e(url('controlPanel/certificates')); ?>"><strong class="color-slate-blue <?php if($page == 'certificates') echo 'selected' ?>">Nuestros certificados</strong></a>
                                                            <a class="text-white mobileBigText d-block noWrap my-3" href="<?php echo e(url('controlPanel/joinUs')); ?>"><strong class="color-slate-blue <?php if($page == 'joinUs') echo 'selected' ?>">Únete a nosotros</strong></a>
                                                            <a class="text-white mobileBigText d-block noWrap my-3" href="<?php echo e(url('controlPanel/administrateOffices')); ?>"><strong class="color-slate-blue <?php if($page == 'offices') echo 'selected' ?>">Ofertas de trabajo</strong></a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <a class="text-white mobileBigText d-md-inline d-block my-3" href="<?php echo e(url('controlPanel/administrateCourses')); ?>"><strong <?php if($page == 'courses') echo 'class="selected"' ?>>Cursos</strong></a>
                                                <a class="text-white mobileBigText d-md-inline d-block my-3" href="<?php echo e(url('controlPanel/administrateNews')); ?>"><strong <?php if($page == 'news') echo 'class="selected"' ?>>Noticias</strong></a>
                                                <a class="text-white mobileBigText d-md-inline d-block my-3" href="<?php echo e(url('controlPanel/administrateContacts')); ?>"><strong <?php if($page == 'contact') echo 'class="selected"' ?>>Contacto</strong></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="container-fluid mt-4 pl-0">
                                <div class="centerHorizontal d-flex">
                                    <a class="previewAnchor" target="_blank"><button class="btn bg-grey text-black-50 noWrap mr-4"><strong>Ver Web</strong></button></a>
                                    <a href="<?php echo e(url('closeSession')); ?>"><button class="btn bg-grey text-black-50 noWrap"><strong>Cerrar sesión</strong></button></a>
                                </div>
                            </div>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </nav>
    <nav class="navbar navbar-expand-lg navbar-dark bg-grey px-5 shadow d-lg-block d-none">
        <div class="container-fluid">
            <div class="row align-items-center w-100">
                <div class="col-12">
                    <div class="d-flex float-right">
                        <a class="px-4" href="<?php echo e(url('controlPanel')); ?>"><strong <?php if($page == '') echo 'class="selected"' ?>>Inicio</strong></a>
                        <div class="showFloatingBox position-relative">
                            <strong class="color-slate-blue <?php if($page == 'aboutUs' || $page == 'certificates' || $page == 'joinUs') echo 'selected' ?>">Conócenos<i class="glyphicon glyphicon-chevron-down ml-1 small"></i></strong>
                            <div class="floatingBox">
                                <div class="bg-grey shadow mt-2">
                                    <a class="mobileBigText d-block noWrap pt-3 px-3" href="<?php echo e(url('controlPanel/aboutUs')); ?>"><strong class="color-slate-blue <?php if($page == 'aboutUs') echo 'selected' ?>">¿Quiénes somos?</strong></a>
                                    <a class="mobileBigText d-block noWrap py-3 px-3" href="<?php echo e(url('controlPanel/certificates')); ?>"><strong class="color-slate-blue <?php if($page == 'certificates') echo 'selected' ?>">Nuestros certificados</strong></a>
                                    <a class="mobileBigText d-block noWrap pb-3 px-3" href="<?php echo e(url('controlPanel/joinUs')); ?>"><strong class="color-slate-blue <?php if($page == 'joinUs') echo 'selected' ?>">Únete a nosotros</strong></a>
                                    <a class="mobileBigText d-block noWrap pb-3 px-3" href="<?php echo e(url('controlPanel/administrateOffices')); ?>"><strong class="color-slate-blue <?php if($page == 'offices') echo 'selected' ?>">Ofertas de trabajo</strong></a>
                                </div>
                            </div>
                        </div>
                        <a class="px-4" href="<?php echo e(url('controlPanel/administrateCourses')); ?>"><strong <?php if($page == 'courses') echo 'class="selected"' ?>>Cursos</strong></a>
                        <a class="px-4" href="<?php echo e(url('controlPanel/administrateNews')); ?>"><strong <?php if($page == 'news') echo 'class="selected"' ?>>Noticias</strong></a>
                        <a class="pl-4" href="<?php echo e(url('controlPanel/administrateContacts')); ?>"><strong <?php if($page == 'contact') echo 'class="selected"' ?>>Contacto</strong></a>
                    </div>
                </div>
            </div>
        </div>
    </nav>
</div>


<div class="position-fixed statusBar bg-white shadow">
    <form id="editPageForm" method="post" enctype="multipart/form-data" action="<?php echo e(url('editPage')); ?>">
        <?php echo e(csrf_field()); ?>

        <input type="hidden" name="page" value="<?php if(isset($page)) echo $page; else echo 'generic'; ?>">
        <input id="editedData" type="hidden" name="value">
        <div class="float-right h-100 px-5 py-3 d-flex align-items-center">
            <i id="cancelEdition" title="Cancelar" class="glyphicon glyphicon-remove color-deep-blue hover-grey interactive iconBig mr-5"></i>
            <i id="saveEdition" title="Guardar" class="glyphicon glyphicon-ok color-deep-blue hover-grey interactive iconBig"></i>
        </div>
    </form>
</div>

<!-- E N D   N A V B A R -->

<?php echo $__env->yieldSection(); ?>
<?php echo $__env->yieldContent('content'); ?>
<?php $__env->startSection('footer'); ?>

<!-- F O O T E R -->

<footer class="page-footer font-small blue pt-4">
    <div class="footer-copyright text-center py-3 bg-deep-blue">
        <span class="text-white">Copyright © <?php echo e(date('Y')); ?> Fuerteventura 2000. Todos los derechos reservados.</span>
    </div>
</footer>

<!-- E N D   F O O T E R -->

<script type="text/javascript" src="<?php echo e(asset('js/controlPanel.js')); ?>"></script>

</body>
</html>
<?php echo $__env->yieldSection(); ?>

<?php /**PATH C:\laragon\www\Fuerteventura2000\resources\views/adminLayout.blade.php ENDPATH**/ ?>