<?php

namespace Fuerteventura2000;

use Illuminate\Database\Eloquent\Model;

class Partner extends Model
{
    protected $fillable = [
        'anchor', 'logo'
    ];
}
