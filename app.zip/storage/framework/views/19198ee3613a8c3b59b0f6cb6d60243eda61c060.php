<?php $__env->startSection('header'); ?>
<?php $__env->startSection('title'); ?>404 <?php $__env->stopSection(); ?>
<?php $__env->startSection('img'); ?><?php echo e(asset('images/404.png')); ?> <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="container-fluid mt-6">
    <div class="row">
        <div class="col-xl-10 offset-xl-1 col-12 offset-0">
            <div class="container-fluid">
                <div class="row align-items-center">
                    <div class="col-xl-6 col-lg-7 d-lg-block d-none">
                        <img class="w-100" src="<?php echo e(asset('images/404.png')); ?>">
                    </div>
                    <div class="col-xl-4 offset-xl-1 col-lg-4 col-12 offset-0">
                        <h1 class="color-deep-blue greatTitle text-center"><strong>404</strong></h1>
                        <h1 class="color-deep-blue text-center mb-4"><strong>Recurso no encontrado</strong></h1>
                        <h6 class="text-center mb-4">
                            El recurso solicitado no ha sido encontrado en el servidor.</br>
                            Puede que haya sido transladado a otro lugar o eliminado definitivamente.
                        </h6>
                        <a href="<?php echo e(url('/')); ?>"><button class="btn color-deep-blue border-deep-blue centerHorizontal px-4 mb-5"><strong>Ir a Inicio</strong></button></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>

<?php echo $__env->make('errors.errorsLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Fuerteventura2000\resources\views/errors/404.blade.php ENDPATH**/ ?>